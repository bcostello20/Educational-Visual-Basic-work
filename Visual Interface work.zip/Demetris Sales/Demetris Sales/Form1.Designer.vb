﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mnuMenu = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuReport = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.gbSalesData = New System.Windows.Forms.GroupBox()
        Me.lstSalesData = New System.Windows.Forms.ListBox()
        Me.lblTotalRevenueDesc = New System.Windows.Forms.Label()
        Me.lblTotalRevenue = New System.Windows.Forms.Label()
        Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuReportEnterSalesData = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuReportDisplaySalesReport = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelpAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMenu.SuspendLayout()
        Me.gbSalesData.SuspendLayout()
        Me.SuspendLayout()
        '
        'mnuMenu
        '
        Me.mnuMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuReport, Me.mnuHelp})
        Me.mnuMenu.Location = New System.Drawing.Point(0, 0)
        Me.mnuMenu.Name = "mnuMenu"
        Me.mnuMenu.Size = New System.Drawing.Size(522, 24)
        Me.mnuMenu.TabIndex = 0
        Me.mnuMenu.Text = "MenuStrip1"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileExit})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(37, 20)
        Me.mnuFile.Text = "&File"
        '
        'mnuReport
        '
        Me.mnuReport.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuReportEnterSalesData, Me.mnuReportDisplaySalesReport})
        Me.mnuReport.Name = "mnuReport"
        Me.mnuReport.Size = New System.Drawing.Size(54, 20)
        Me.mnuReport.Text = "&Report"
        '
        'mnuHelp
        '
        Me.mnuHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuHelpAbout})
        Me.mnuHelp.Name = "mnuHelp"
        Me.mnuHelp.Size = New System.Drawing.Size(44, 20)
        Me.mnuHelp.Text = "&Help"
        '
        'gbSalesData
        '
        Me.gbSalesData.Controls.Add(Me.lstSalesData)
        Me.gbSalesData.Location = New System.Drawing.Point(12, 48)
        Me.gbSalesData.Name = "gbSalesData"
        Me.gbSalesData.Size = New System.Drawing.Size(494, 324)
        Me.gbSalesData.TabIndex = 1
        Me.gbSalesData.TabStop = False
        Me.gbSalesData.Text = "Sales Data"
        '
        'lstSalesData
        '
        Me.lstSalesData.FormattingEnabled = True
        Me.lstSalesData.Location = New System.Drawing.Point(17, 19)
        Me.lstSalesData.Name = "lstSalesData"
        Me.lstSalesData.Size = New System.Drawing.Size(461, 290)
        Me.lstSalesData.TabIndex = 0
        '
        'lblTotalRevenueDesc
        '
        Me.lblTotalRevenueDesc.AutoSize = True
        Me.lblTotalRevenueDesc.Location = New System.Drawing.Point(307, 387)
        Me.lblTotalRevenueDesc.Name = "lblTotalRevenueDesc"
        Me.lblTotalRevenueDesc.Size = New System.Drawing.Size(78, 13)
        Me.lblTotalRevenueDesc.TabIndex = 2
        Me.lblTotalRevenueDesc.Text = "Total Revenue"
        '
        'lblTotalRevenue
        '
        Me.lblTotalRevenue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalRevenue.Location = New System.Drawing.Point(390, 386)
        Me.lblTotalRevenue.Name = "lblTotalRevenue"
        Me.lblTotalRevenue.Size = New System.Drawing.Size(100, 23)
        Me.lblTotalRevenue.TabIndex = 3
        '
        'mnuFileExit
        '
        Me.mnuFileExit.Name = "mnuFileExit"
        Me.mnuFileExit.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Q), System.Windows.Forms.Keys)
        Me.mnuFileExit.Size = New System.Drawing.Size(180, 22)
        Me.mnuFileExit.Text = "E&xit"
        '
        'mnuReportEnterSalesData
        '
        Me.mnuReportEnterSalesData.Name = "mnuReportEnterSalesData"
        Me.mnuReportEnterSalesData.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.mnuReportEnterSalesData.Size = New System.Drawing.Size(221, 22)
        Me.mnuReportEnterSalesData.Text = "&Enter Sales Data"
        '
        'mnuReportDisplaySalesReport
        '
        Me.mnuReportDisplaySalesReport.Name = "mnuReportDisplaySalesReport"
        Me.mnuReportDisplaySalesReport.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D), System.Windows.Forms.Keys)
        Me.mnuReportDisplaySalesReport.Size = New System.Drawing.Size(221, 22)
        Me.mnuReportDisplaySalesReport.Text = "&Display Sales Report"
        '
        'mnuHelpAbout
        '
        Me.mnuHelpAbout.Name = "mnuHelpAbout"
        Me.mnuHelpAbout.Size = New System.Drawing.Size(180, 22)
        Me.mnuHelpAbout.Text = "&About"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(522, 422)
        Me.Controls.Add(Me.lblTotalRevenue)
        Me.Controls.Add(Me.lblTotalRevenueDesc)
        Me.Controls.Add(Me.gbSalesData)
        Me.Controls.Add(Me.mnuMenu)
        Me.MainMenuStrip = Me.mnuMenu
        Me.Name = "Form1"
        Me.Text = "Demetris Leadership Center"
        Me.mnuMenu.ResumeLayout(False)
        Me.mnuMenu.PerformLayout()
        Me.gbSalesData.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents mnuMenu As MenuStrip
    Friend WithEvents mnuFile As ToolStripMenuItem
    Friend WithEvents mnuReport As ToolStripMenuItem
    Friend WithEvents mnuHelp As ToolStripMenuItem
    Friend WithEvents gbSalesData As GroupBox
    Friend WithEvents lstSalesData As ListBox
    Friend WithEvents lblTotalRevenueDesc As Label
    Friend WithEvents lblTotalRevenue As Label
    Friend WithEvents mnuFileExit As ToolStripMenuItem
    Friend WithEvents mnuReportEnterSalesData As ToolStripMenuItem
    Friend WithEvents mnuReportDisplaySalesReport As ToolStripMenuItem
    Friend WithEvents mnuHelpAbout As ToolStripMenuItem
End Class
