﻿Public Class Form1

    Private Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        ' Display some text inside the list box
        lstOutput.Items.Add("Hello from the btnGo_Click procedure.")
        lstOutput.Items.Add("Now I am calling the DisplayMessage procedure.")

        ' Call the DisplayMessage procedure
        DisplayMessage()

        ' Display more text inside the list box
        lstOutput.Items.Add("Now I am back in the btnGo_Click procedure.")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'End the program
        Me.Close()
    End Sub

    Public Sub DisplayMessage()
        ' This procedure displays a message
        lstOutput.Items.Add("")
        lstOutput.Items.Add("Hello from the DisplayMessage procedure.")
        lstOutput.Items.Add("")
    End Sub

End Class
