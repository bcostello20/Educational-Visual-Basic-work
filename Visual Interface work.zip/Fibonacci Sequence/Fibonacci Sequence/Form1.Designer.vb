﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFibonacciSequence
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstOutput = New System.Windows.Forms.ListBox()
        Me.btnShowFibNumbers = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblInstruction = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lstOutput
        '
        Me.lstOutput.FormattingEnabled = True
        Me.lstOutput.Location = New System.Drawing.Point(35, 34)
        Me.lstOutput.MultiColumn = True
        Me.lstOutput.Name = "lstOutput"
        Me.lstOutput.Size = New System.Drawing.Size(413, 225)
        Me.lstOutput.TabIndex = 0
        '
        'btnShowFibNumbers
        '
        Me.btnShowFibNumbers.Location = New System.Drawing.Point(82, 275)
        Me.btnShowFibNumbers.Name = "btnShowFibNumbers"
        Me.btnShowFibNumbers.Size = New System.Drawing.Size(132, 49)
        Me.btnShowFibNumbers.TabIndex = 1
        Me.btnShowFibNumbers.Text = "Show Fibonacci Numbers"
        Me.btnShowFibNumbers.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(263, 275)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(132, 49)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblInstruction
        '
        Me.lblInstruction.AutoSize = True
        Me.lblInstruction.Location = New System.Drawing.Point(107, 9)
        Me.lblInstruction.Name = "lblInstruction"
        Me.lblInstruction.Size = New System.Drawing.Size(257, 13)
        Me.lblInstruction.TabIndex = 3
        Me.lblInstruction.Text = "This program displays the first 44 Fibonacci Numbers."
        '
        'frmFibonacciSequence
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(485, 348)
        Me.Controls.Add(Me.lblInstruction)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnShowFibNumbers)
        Me.Controls.Add(Me.lstOutput)
        Me.Name = "frmFibonacciSequence"
        Me.Text = "Fibonacci Sequence"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstOutput As ListBox
    Friend WithEvents btnShowFibNumbers As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblInstruction As Label
End Class
