﻿Public Class frmFibonacciSequence
    Private Sub btnShowFibNumbers_Click(sender As Object, e As EventArgs) Handles btnShowFibNumbers.Click
        ' Display the Fibonacci Numbers
        FibonacciNumbers()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' End the program
        Me.Close()
    End Sub

    Private Sub FibonacciNumbers()
        Dim num1 As Integer = 0
        Dim num2 As Integer = 1
        Dim fib As Integer = 0

        ' Use a loop to display to calculate and then display the Fibonacci Numbers
        ' This does not want to print out all 44 fibonacci numbers and I'm not sure why
        Do
            fib = num1 + num2
            num1 = num2
            num2 = fib
            lstOutput.Items.Add(fib.ToString())
        Loop While fib <= 44
    End Sub

End Class
