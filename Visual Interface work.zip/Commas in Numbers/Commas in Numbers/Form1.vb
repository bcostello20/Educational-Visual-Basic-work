﻿Public Class formCommasInNumbers

    Dim theString As String ' The number string we are getting from the textbox that the user enters

    Private Sub btnNoCommas_Click(sender As Object, e As EventArgs) Handles btnNoCommas.Click

        ' Set theString equal to the textbox text
        theString = txtNumber.Text

        ' Go through theString replacing any commas with an empty string
        theString = theString.Replace(",", String.Empty)

        ' Display theString with no commas on the screen for the user
        lblDisplayNumber.Text = theString

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        ' End the program
        Me.Close()

    End Sub
End Class
