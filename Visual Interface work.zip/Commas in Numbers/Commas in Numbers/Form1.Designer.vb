﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formCommasInNumbers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.txtNumber = New System.Windows.Forms.TextBox()
        Me.lblDisplayNumber = New System.Windows.Forms.Label()
        Me.lblNumber = New System.Windows.Forms.Label()
        Me.btnNoCommas = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Location = New System.Drawing.Point(29, 37)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(238, 13)
        Me.lblInstructions.TabIndex = 0
        Me.lblInstructions.Text = "Enter a number with no more than three commas:"
        '
        'txtNumber
        '
        Me.txtNumber.Location = New System.Drawing.Point(273, 34)
        Me.txtNumber.Name = "txtNumber"
        Me.txtNumber.Size = New System.Drawing.Size(159, 20)
        Me.txtNumber.TabIndex = 1
        '
        'lblDisplayNumber
        '
        Me.lblDisplayNumber.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisplayNumber.Location = New System.Drawing.Point(273, 68)
        Me.lblDisplayNumber.Name = "lblDisplayNumber"
        Me.lblDisplayNumber.Size = New System.Drawing.Size(159, 23)
        Me.lblDisplayNumber.TabIndex = 2
        '
        'lblNumber
        '
        Me.lblNumber.AutoSize = True
        Me.lblNumber.Location = New System.Drawing.Point(121, 69)
        Me.lblNumber.Name = "lblNumber"
        Me.lblNumber.Size = New System.Drawing.Size(146, 13)
        Me.lblNumber.TabIndex = 3
        Me.lblNumber.Text = "The number without commas:"
        '
        'btnNoCommas
        '
        Me.btnNoCommas.Location = New System.Drawing.Point(86, 111)
        Me.btnNoCommas.Name = "btnNoCommas"
        Me.btnNoCommas.Size = New System.Drawing.Size(104, 38)
        Me.btnNoCommas.TabIndex = 4
        Me.btnNoCommas.Text = "Show No Commas"
        Me.btnNoCommas.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(273, 111)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(105, 38)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'formCommasInNumbers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(467, 161)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnNoCommas)
        Me.Controls.Add(Me.lblNumber)
        Me.Controls.Add(Me.lblDisplayNumber)
        Me.Controls.Add(Me.txtNumber)
        Me.Controls.Add(Me.lblInstructions)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "formCommasInNumbers"
        Me.Text = "Commas in Numbers"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblInstructions As Label
    Friend WithEvents txtNumber As TextBox
    Friend WithEvents lblDisplayNumber As Label
    Friend WithEvents lblNumber As Label
    Friend WithEvents btnNoCommas As Button
    Friend WithEvents btnExit As Button
End Class
