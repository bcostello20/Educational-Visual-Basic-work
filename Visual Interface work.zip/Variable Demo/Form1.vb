﻿Public Class Form1
    Private Sub BtnShowName_Click(sender As Object, e As EventArgs) Handles btnShowName.Click
        Dim strFullName As String

        strFullName = txtFirstName.Text & " " & txtLastName.Text

        lblFullName.Text = strFullName
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtFirstName.Clear()
        txtLastName.Clear()
        lblFullName.Text = String.Empty
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
