﻿Public Class Form1
    Private Sub btnConvert_Click(sender As Object, e As EventArgs) Handles btnConvert.Click
        Dim number As Integer ' Number variable default for the Select Case

        ' Convert the textbox String value to an Integer
        Integer.TryParse(txtDecimalInt.Text, number)

        ' Input validation for numbers greater than 1 but less than 10
        If number < 1 Or number > 10 Then
            MessageBox.Show("Number must be greater than 1 but less than 10, please try again.")
            txtDecimalInt.Clear() ' Clear the textbox
            lblRomanNumeral.Text = String.Empty ' Clear the label
        End If

        ' Select case to decide which Roman Numeral to display based on Integer value entered by user
        Select Case number
            Case 1
                lblRomanNumeral.Text = "I"
            Case 2
                lblRomanNumeral.Text = "II"
            Case 3
                lblRomanNumeral.Text = "III"
            Case 4
                lblRomanNumeral.Text = "IV"
            Case 5
                lblRomanNumeral.Text = "V"
            Case 6
                lblRomanNumeral.Text = "VI"
            Case 7
                lblRomanNumeral.Text = "VII"
            Case 8
                lblRomanNumeral.Text = "VIII"
            Case 9
                lblRomanNumeral.Text = "IX"
            Case 10
                lblRomanNumeral.Text = "X"
        End Select
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
