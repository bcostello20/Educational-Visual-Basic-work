﻿Public Class formSumofNumbers
    Private Sub BtnMaxValue_Click(sender As Object, e As EventArgs) Handles btnMaxValue.Click
        Dim intMaxValue As Integer ' The max value from user
        Dim sum As Integer ' The total of 1 plus max value from user
        Dim strUserInput As String =
            InputBox("Enter a positive integer to be used as the maximum value.", "Input Needed", "10")

        ' Convert the max value string to an Integer
        intMaxValue = CInt(strUserInput)

        'Input validation for positive values only
        If (intMaxValue < 0) Then
            ' Error Message
            MessageBox.Show("ERROR: Numeric values must be positive.")
        End If

        ' Loop through each value between 1 and the max value
        For index As Integer = 1 To intMaxValue
            ' Add the values to sum
            sum += index
        Next

        ' Display the sum to the screen for the user
        MessageBox.Show("The sum of numbers 1 through " & intMaxValue & " is " & sum.ToString)

    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' End the program
        Me.Close()
    End Sub
End Class
