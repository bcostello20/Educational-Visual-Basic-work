﻿Public Class Form1
    Private Sub btnOne_Click(sender As Object, e As EventArgs) Handles btnOne.Click
        ' Display the French word for one.
        MessageBox.Show("un")

    End Sub

    Private Sub btnTwo_Click(sender As Object, e As EventArgs) Handles btnTwo.Click
        ' Display the French word for two.
        MessageBox.Show("deux")
    End Sub

    Private Sub btnThree_Click(sender As Object, e As EventArgs) Handles btnThree.Click
        ' Display the French word for three.
        MessageBox.Show("trois")
    End Sub

    Private Sub btnFour_Click(sender As Object, e As EventArgs) Handles btnFour.Click
        ' Display the French word for four.
        MessageBox.Show("quatre")
    End Sub

    Private Sub btnFive_Click(sender As Object, e As EventArgs) Handles btnFive.Click
        ' Display the French word for five.
        MessageBox.Show("cinq")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' Close the form.
        Me.Close()
    End Sub
End Class
