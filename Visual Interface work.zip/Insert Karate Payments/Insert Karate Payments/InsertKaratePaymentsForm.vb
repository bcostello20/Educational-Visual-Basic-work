﻿Public Class InsertKaratePaymentsForm
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'PaymentsDataSet.Payments' table. You can move, or remove it, as needed.
        Me.PaymentsTableAdapter.Fill(Me.PaymentsDataSet.Payments)

        ' Set the text box to today's date.
        txtDate.Text = Today().ToString("d")

    End Sub

    Private Sub btnInsert_Click(sender As Object, e As EventArgs) Handles btnInsert.Click
        ' Insert a new Member ID, a Date, and an Amount into the Payments table
        Try
            Me.PaymentsTableAdapter.Insert(CShort(txtMemberId.Text),
                CDate(txtDate.Text), CDec(txtAmount.Text))
            Me.PaymentsTableAdapter.Fill(PaymentsDataSet.Payments)
        Catch ex As Exception
            ' If any input is invalid show the default error message for the exception
            MessageBox.Show(ex.Message, "Data Input Error")
        End Try
    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        ' End the program
        Me.Close()
    End Sub
End Class
