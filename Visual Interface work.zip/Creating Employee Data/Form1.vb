﻿Imports System.IO

Public Class Form1

    Dim newFile As StreamWriter ' Instance of the StreamWriter object
    Dim strFileName As String ' To hold the file name

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Get a file name from the user
        strFileName = InputBox("Enter name of file.")

        ' Check if the file exists, if not create a new file
        If System.IO.File.Exists(strFileName) Then
            ' Do nothing here?
        Else
            newFile = File.CreateText(strFileName)
            newFile.WriteLine(txtFirstName.Text)
            newFile.WriteLine(txtMiddleName.Text)
            newFile.WriteLine(txtLastName.Text)
            newFile.WriteLine(txtEmployeeNumber.Text)
            newFile.WriteLine(cboDepartment.Text)
            newFile.WriteLine(txtTelephone.Text)
            newFile.WriteLine(txtExtension.Text)
            newFile.WriteLine(txtEmailAddress.Text)
            newFile.Close()
        End If
    End Sub

    Private Sub BtnSaveRecord_Click(sender As Object, e As EventArgs) Handles btnSaveRecord.Click
        ' Save and append the text box inputs to the created file
        newFile = File.AppendText(strFileName)
        newFile.WriteLine(txtFirstName.Text)
        newFile.WriteLine(txtMiddleName.Text)
        newFile.WriteLine(txtLastName.Text)
        newFile.WriteLine(txtEmployeeNumber.Text)
        newFile.WriteLine(cboDepartment.Text)
        newFile.WriteLine(txtTelephone.Text)
        newFile.WriteLine(txtExtension.Text)
        newFile.WriteLine(txtEmailAddress.Text)
        newFile.Close()
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clear the text boxes
        txtFirstName.Clear()
        txtMiddleName.Clear()
        txtLastName.Clear()
        txtEmployeeNumber.Clear()
        cboDepartment.Text = String.Empty
        txtTelephone.Clear()
        txtExtension.Clear()
        txtEmailAddress.Clear()
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' End the program
        Me.Close()
    End Sub

End Class
