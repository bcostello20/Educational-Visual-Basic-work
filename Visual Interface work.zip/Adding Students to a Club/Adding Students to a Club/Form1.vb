﻿Public Class formAddingStudentstoaClub

    Private Sub btnAddSelectedStudent_Click(sender As Object, e As EventArgs) Handles btnAddSelectedStudent.Click
        ' Add the selected student to the membership list
        AddMember()
    End Sub

    Private Sub btnRemovedSelectedMember_Click(sender As Object, e As EventArgs) Handles btnRemovedSelectedMember.Click
        ' Remove the selected student from the membership list
        RemoveMember()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' End the program
        Me.Close()
    End Sub

    ' AddMember method when called copies a selected item from student list to the membership list
    Public Sub AddMember()
        ' If the selected student is not already in the membership list, add it
        Try
            If Not lstClubMembershipList.Items.Contains(lstStudentList.SelectedItem) Then
                lstClubMembershipList.Items.Add(lstStudentList.SelectedItem)
            End If
        Catch
            ' Error message if no student is selected when trying to add
            MessageBox.Show("You must select a student to add.")
        End Try

        ' Update the member count label + 1
        lblMemberCount.Text = lstClubMembershipList.Items.Count().ToString + " members"

    End Sub

    'RemoveMember method when called removes a selected item from the membership list
    Public Sub RemoveMember()
        ' This Try-Catch doesn't seem to work here or in button OnClick method, however it does not give a runtime error either way for some reason
        Try
            lstClubMembershipList.Items.Remove(lstClubMembershipList.SelectedItem)
        Catch
            ' Error message if no student is selected when trying to remove
            MessageBox.Show("You must select a student to remove.")
        End Try

        ' Update the member count label - 1
        lblMemberCount.Text = lstClubMembershipList.Items.Count().ToString + " members"

    End Sub

End Class
