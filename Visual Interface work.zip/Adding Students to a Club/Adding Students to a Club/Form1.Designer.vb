﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formAddingStudentstoaClub
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formAddingStudentstoaClub))
        Me.lblInstruction = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblMemberCount = New System.Windows.Forms.Label()
        Me.btnRemovedSelectedMember = New System.Windows.Forms.Button()
        Me.lstClubMembershipList = New System.Windows.Forms.ListBox()
        Me.lblClubMembershipDesc = New System.Windows.Forms.Label()
        Me.btnAddSelectedStudent = New System.Windows.Forms.Button()
        Me.lstStudentList = New System.Windows.Forms.ListBox()
        Me.lblStudentListDesc = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblInstruction
        '
        Me.lblInstruction.Location = New System.Drawing.Point(119, 31)
        Me.lblInstruction.Name = "lblInstruction"
        Me.lblInstruction.Size = New System.Drawing.Size(511, 29)
        Me.lblInstruction.TabIndex = 0
        Me.lblInstruction.Text = resources.GetString("lblInstruction.Text")
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.GroupBox1.Controls.Add(Me.btnExit)
        Me.GroupBox1.Controls.Add(Me.lblMemberCount)
        Me.GroupBox1.Controls.Add(Me.btnRemovedSelectedMember)
        Me.GroupBox1.Controls.Add(Me.lstClubMembershipList)
        Me.GroupBox1.Controls.Add(Me.lblClubMembershipDesc)
        Me.GroupBox1.Controls.Add(Me.btnAddSelectedStudent)
        Me.GroupBox1.Controls.Add(Me.lstStudentList)
        Me.GroupBox1.Controls.Add(Me.lblStudentListDesc)
        Me.GroupBox1.Location = New System.Drawing.Point(47, 90)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(680, 334)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        '
        'lblMemberCount
        '
        Me.lblMemberCount.Location = New System.Drawing.Point(525, 239)
        Me.lblMemberCount.Name = "lblMemberCount"
        Me.lblMemberCount.Size = New System.Drawing.Size(100, 23)
        Me.lblMemberCount.TabIndex = 6
        Me.lblMemberCount.Text = "0 members"
        '
        'btnRemovedSelectedMember
        '
        Me.btnRemovedSelectedMember.Location = New System.Drawing.Point(528, 121)
        Me.btnRemovedSelectedMember.Name = "btnRemovedSelectedMember"
        Me.btnRemovedSelectedMember.Size = New System.Drawing.Size(86, 93)
        Me.btnRemovedSelectedMember.TabIndex = 5
        Me.btnRemovedSelectedMember.Text = "Remove selected member"
        Me.btnRemovedSelectedMember.UseVisualStyleBackColor = True
        '
        'lstClubMembershipList
        '
        Me.lstClubMembershipList.FormattingEnabled = True
        Me.lstClubMembershipList.Location = New System.Drawing.Point(358, 61)
        Me.lstClubMembershipList.Name = "lstClubMembershipList"
        Me.lstClubMembershipList.Size = New System.Drawing.Size(155, 225)
        Me.lstClubMembershipList.TabIndex = 4
        '
        'lblClubMembershipDesc
        '
        Me.lblClubMembershipDesc.AutoSize = True
        Me.lblClubMembershipDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClubMembershipDesc.Location = New System.Drawing.Point(355, 32)
        Me.lblClubMembershipDesc.Name = "lblClubMembershipDesc"
        Me.lblClubMembershipDesc.Size = New System.Drawing.Size(163, 17)
        Me.lblClubMembershipDesc.TabIndex = 3
        Me.lblClubMembershipDesc.Text = "Club Membership List"
        '
        'btnAddSelectedStudent
        '
        Me.btnAddSelectedStudent.Location = New System.Drawing.Point(255, 121)
        Me.btnAddSelectedStudent.Name = "btnAddSelectedStudent"
        Me.btnAddSelectedStudent.Size = New System.Drawing.Size(86, 93)
        Me.btnAddSelectedStudent.TabIndex = 2
        Me.btnAddSelectedStudent.Text = "Add selected student"
        Me.btnAddSelectedStudent.UseVisualStyleBackColor = True
        '
        'lstStudentList
        '
        Me.lstStudentList.FormattingEnabled = True
        Me.lstStudentList.Items.AddRange(New Object() {"Adams, Ben", "Baker, Sally", "Canseco, Juan", "Davis, Sharon", "Etienne, Jean", "Gonzalez, Jose", "Johnson, Eric", "Koenig, Johann", "Matsunaga, Akiko", "Nakamura, Ken", "Ramirez, Maria"})
        Me.lstStudentList.Location = New System.Drawing.Point(84, 61)
        Me.lstStudentList.Name = "lstStudentList"
        Me.lstStudentList.Size = New System.Drawing.Size(155, 225)
        Me.lstStudentList.TabIndex = 1
        '
        'lblStudentListDesc
        '
        Me.lblStudentListDesc.AutoSize = True
        Me.lblStudentListDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStudentListDesc.Location = New System.Drawing.Point(81, 32)
        Me.lblStudentListDesc.Name = "lblStudentListDesc"
        Me.lblStudentListDesc.Size = New System.Drawing.Size(158, 17)
        Me.lblStudentListDesc.TabIndex = 0
        Me.lblStudentListDesc.Text = "General Student List"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(599, 305)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'formAddingStudentstoaClub
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(775, 450)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lblInstruction)
        Me.Name = "formAddingStudentstoaClub"
        Me.Text = "Adding Students to a Club"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblInstruction As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnRemovedSelectedMember As Button
    Friend WithEvents lstClubMembershipList As ListBox
    Friend WithEvents lblClubMembershipDesc As Label
    Friend WithEvents btnAddSelectedStudent As Button
    Friend WithEvents lstStudentList As ListBox
    Friend WithEvents lblStudentListDesc As Label
    Friend WithEvents lblMemberCount As Label
    Friend WithEvents btnExit As Button
End Class
