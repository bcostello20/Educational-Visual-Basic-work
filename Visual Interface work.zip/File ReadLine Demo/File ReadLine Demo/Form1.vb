﻿Imports System.IO

Public Class Form1
    Private Sub btnRead_Click(sender As Object, e As EventArgs) Handles btnRead.Click
        ' Constant for number of friends
        Const intNUM_FRIENDS As Integer = 4

        ' Local variables
        Dim friendFile As StreamReader ' Instance of the StreamReader object
        Dim strFilename As String ' The file name
        Dim strFriend As String ' The name of a friend
        Dim strPhone As String ' The friend's phone number
        Dim intCount As Integer ' Counter for loop

        ' Get the file name from the user
        strFilename = InputBox("Enter the filename.")

        Try
            ' Opening the file
            friendFile = File.OpenText(strFilename)

            ' Read in the data
            For intCount = 1 To intNUM_FRIENDS
                ' Read in a name and phone number from the file
                strFriend = friendFile.ReadLine()
                strPhone = friendFile.ReadLine()

                ' Display the data in the list box
                lstFriends.Items.Add("Friend Number " & intCount.ToString())
                lstFriends.Items.Add("Name: " & strFriend)
                lstFriends.Items.Add("Phone: " & strPhone)
                lstFriends.Items.Add("") ' Have a blank line
            Next intCount

            ' Close the file
            friendFile.Close()

        Catch
            MessageBox.Show("That file cannot be opened.")
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clear the list box
        lstFriends.Items.Clear()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' End the program
        Me.Close()
    End Sub
End Class
