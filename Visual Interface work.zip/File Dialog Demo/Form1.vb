﻿Imports System.IO
Public Class Form1

    Private Sub MnuFileOpen_Click(sender As Object, e As EventArgs) Handles mnuFileOpen.Click
        ofdChooseFile.InitialDirectory = "C:\" ' The starting directory for the file dialog

        Dim inputFile As StreamReader ' The object

        With ofdChooseFile
            .Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*"
            .Title = "Select a File to Open"
            If .ShowDialog() = Windows.Forms.DialogResult.OK Then
                inputFile = File.OpenText(.FileName) ' Get the file name
                Try
                    txtDocument.Text = inputFile.ReadToEnd ' Read all file contents into the text box

                    ' Close the file
                    inputFile.Close()
                Catch ex As Exception
                    ' Error message for file opening
                    MessageBox.Show("Error opening the file")
                End Try
            End If
        End With
    End Sub

    Private Sub MnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        ' End the program
        Me.Close()
    End Sub

    Private Sub mnuFileSave_Click(sender As Object, e As EventArgs) Handles mnuFileSave.Click
        Dim infoFile As StreamWriter
        Dim strFileName As String

        'Try
        '    infoFile = File.CreateText("E:\info.txt")
        '    infoFile.WriteLine(txtDocument.Text)
        '    infoFile.Close()
        'Catch
        '    MessageBox.Show("Error: The file cannot be created.")
        'End Try

        sfdSaveFile.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*"

        If sfdSaveFile.ShowDialog() = Windows.Forms.DialogResult.OK Then
            strFileName = sfdSaveFile.FileName
            Try
                infoFile = File.CreateText(strFileName)
                infoFile.WriteLine(txtDocument.Text)
                infoFile.Close()
            Catch
                MessageBox.Show("Error: The file cannot be created.")
            End Try
        End If
    End Sub

    Private Sub MnuEditColor_Click(sender As Object, e As EventArgs) Handles mnuEditColor.Click
        If cdColor.ShowDialog() = Windows.Forms.DialogResult.OK Then
            txtDocument.ForeColor = cdColor.Color
        End If
    End Sub

    Private Sub MnuEditFont_Click(sender As Object, e As EventArgs) Handles mnuEditFont.Click
        If fdFont.ShowDialog() = Windows.Forms.DialogResult.OK Then
            txtDocument.Font = fdFont.Font
        End If
    End Sub

    Private Sub MnuFilePrint_Click(sender As Object, e As EventArgs) Handles mnuFilePrint.Click
        If pdPrint.ShowDialog() = DialogResult.OK Then
            pddPrintDocument.PrinterSettings = pddPrintDocument.PrinterSettings
            pddPrintDocument.Print()
        End If
    End Sub

    Private Sub PddPrintDocument_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles pddPrintDocument.PrintPage
        e.Graphics.DrawString(txtDocument.Text, New Font("MS Sans Serif", 12, FontStyle.Regular), Brushes.Black, 10, 10)
    End Sub
End Class
