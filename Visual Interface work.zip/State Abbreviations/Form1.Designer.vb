﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnVirginia = New System.Windows.Forms.Button()
        Me.btnNorthCarolina = New System.Windows.Forms.Button()
        Me.btnSouthCarolina = New System.Windows.Forms.Button()
        Me.btnGeorgia = New System.Windows.Forms.Button()
        Me.btnAlabama = New System.Windows.Forms.Button()
        Me.btnFlorida = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblShowAbbreviation = New System.Windows.Forms.Label()
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.picVirginia = New System.Windows.Forms.PictureBox()
        Me.picNorthCarolina = New System.Windows.Forms.PictureBox()
        Me.picSouthCarolina = New System.Windows.Forms.PictureBox()
        Me.picGeorgia = New System.Windows.Forms.PictureBox()
        Me.picAlabama = New System.Windows.Forms.PictureBox()
        Me.picFlorida = New System.Windows.Forms.PictureBox()
        Me.ssShowAbbreviations = New System.Windows.Forms.StatusStrip()
        Me.tsShowAbbreviations = New System.Windows.Forms.ToolStripStatusLabel()
        CType(Me.picVirginia, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picNorthCarolina, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSouthCarolina, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGeorgia, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAlabama, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFlorida, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ssShowAbbreviations.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnVirginia
        '
        Me.btnVirginia.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnVirginia.Location = New System.Drawing.Point(27, 101)
        Me.btnVirginia.Name = "btnVirginia"
        Me.btnVirginia.Size = New System.Drawing.Size(75, 48)
        Me.btnVirginia.TabIndex = 0
        Me.btnVirginia.Text = "Virginia"
        Me.btnVirginia.UseVisualStyleBackColor = False
        '
        'btnNorthCarolina
        '
        Me.btnNorthCarolina.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnNorthCarolina.Location = New System.Drawing.Point(108, 101)
        Me.btnNorthCarolina.Name = "btnNorthCarolina"
        Me.btnNorthCarolina.Size = New System.Drawing.Size(75, 48)
        Me.btnNorthCarolina.TabIndex = 1
        Me.btnNorthCarolina.Text = "North Carolina"
        Me.btnNorthCarolina.UseVisualStyleBackColor = False
        '
        'btnSouthCarolina
        '
        Me.btnSouthCarolina.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnSouthCarolina.Location = New System.Drawing.Point(189, 101)
        Me.btnSouthCarolina.Name = "btnSouthCarolina"
        Me.btnSouthCarolina.Size = New System.Drawing.Size(75, 48)
        Me.btnSouthCarolina.TabIndex = 2
        Me.btnSouthCarolina.Text = "South Carolina"
        Me.btnSouthCarolina.UseVisualStyleBackColor = False
        '
        'btnGeorgia
        '
        Me.btnGeorgia.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnGeorgia.Location = New System.Drawing.Point(270, 101)
        Me.btnGeorgia.Name = "btnGeorgia"
        Me.btnGeorgia.Size = New System.Drawing.Size(75, 48)
        Me.btnGeorgia.TabIndex = 3
        Me.btnGeorgia.Text = "Georgia"
        Me.btnGeorgia.UseVisualStyleBackColor = False
        '
        'btnAlabama
        '
        Me.btnAlabama.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnAlabama.Location = New System.Drawing.Point(351, 101)
        Me.btnAlabama.Name = "btnAlabama"
        Me.btnAlabama.Size = New System.Drawing.Size(75, 48)
        Me.btnAlabama.TabIndex = 4
        Me.btnAlabama.Text = "Alabama"
        Me.btnAlabama.UseVisualStyleBackColor = False
        '
        'btnFlorida
        '
        Me.btnFlorida.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnFlorida.Location = New System.Drawing.Point(432, 101)
        Me.btnFlorida.Name = "btnFlorida"
        Me.btnFlorida.Size = New System.Drawing.Size(75, 48)
        Me.btnFlorida.TabIndex = 5
        Me.btnFlorida.Text = "Florida"
        Me.btnFlorida.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.Black
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.Location = New System.Drawing.Point(231, 260)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'lblShowAbbreviation
        '
        Me.lblShowAbbreviation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblShowAbbreviation.Location = New System.Drawing.Point(215, 50)
        Me.lblShowAbbreviation.Name = "lblShowAbbreviation"
        Me.lblShowAbbreviation.Size = New System.Drawing.Size(100, 23)
        Me.lblShowAbbreviation.TabIndex = 7
        Me.lblShowAbbreviation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblShowAbbreviation.Visible = False
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Location = New System.Drawing.Point(161, 9)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(209, 13)
        Me.lblInstructions.TabIndex = 8
        Me.lblInstructions.Text = "Click a button to see the state abbreviation"
        '
        'picVirginia
        '
        Me.picVirginia.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picVirginia.Image = CType(resources.GetObject("picVirginia.Image"), System.Drawing.Image)
        Me.picVirginia.Location = New System.Drawing.Point(27, 155)
        Me.picVirginia.Name = "picVirginia"
        Me.picVirginia.Size = New System.Drawing.Size(75, 90)
        Me.picVirginia.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picVirginia.TabIndex = 9
        Me.picVirginia.TabStop = False
        Me.picVirginia.Visible = False
        '
        'picNorthCarolina
        '
        Me.picNorthCarolina.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picNorthCarolina.Image = CType(resources.GetObject("picNorthCarolina.Image"), System.Drawing.Image)
        Me.picNorthCarolina.Location = New System.Drawing.Point(108, 155)
        Me.picNorthCarolina.Name = "picNorthCarolina"
        Me.picNorthCarolina.Size = New System.Drawing.Size(75, 90)
        Me.picNorthCarolina.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picNorthCarolina.TabIndex = 10
        Me.picNorthCarolina.TabStop = False
        Me.picNorthCarolina.Visible = False
        '
        'picSouthCarolina
        '
        Me.picSouthCarolina.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picSouthCarolina.Image = CType(resources.GetObject("picSouthCarolina.Image"), System.Drawing.Image)
        Me.picSouthCarolina.Location = New System.Drawing.Point(189, 155)
        Me.picSouthCarolina.Name = "picSouthCarolina"
        Me.picSouthCarolina.Size = New System.Drawing.Size(75, 90)
        Me.picSouthCarolina.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picSouthCarolina.TabIndex = 11
        Me.picSouthCarolina.TabStop = False
        Me.picSouthCarolina.Visible = False
        '
        'picGeorgia
        '
        Me.picGeorgia.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picGeorgia.Image = CType(resources.GetObject("picGeorgia.Image"), System.Drawing.Image)
        Me.picGeorgia.Location = New System.Drawing.Point(270, 155)
        Me.picGeorgia.Name = "picGeorgia"
        Me.picGeorgia.Size = New System.Drawing.Size(75, 90)
        Me.picGeorgia.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picGeorgia.TabIndex = 12
        Me.picGeorgia.TabStop = False
        Me.picGeorgia.Visible = False
        '
        'picAlabama
        '
        Me.picAlabama.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picAlabama.Image = CType(resources.GetObject("picAlabama.Image"), System.Drawing.Image)
        Me.picAlabama.Location = New System.Drawing.Point(351, 155)
        Me.picAlabama.Name = "picAlabama"
        Me.picAlabama.Size = New System.Drawing.Size(75, 90)
        Me.picAlabama.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picAlabama.TabIndex = 13
        Me.picAlabama.TabStop = False
        Me.picAlabama.Visible = False
        '
        'picFlorida
        '
        Me.picFlorida.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picFlorida.Image = CType(resources.GetObject("picFlorida.Image"), System.Drawing.Image)
        Me.picFlorida.Location = New System.Drawing.Point(432, 155)
        Me.picFlorida.Name = "picFlorida"
        Me.picFlorida.Size = New System.Drawing.Size(75, 90)
        Me.picFlorida.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFlorida.TabIndex = 14
        Me.picFlorida.TabStop = False
        Me.picFlorida.Visible = False
        '
        'ssShowAbbreviations
        '
        Me.ssShowAbbreviations.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsShowAbbreviations})
        Me.ssShowAbbreviations.Location = New System.Drawing.Point(0, 296)
        Me.ssShowAbbreviations.Name = "ssShowAbbreviations"
        Me.ssShowAbbreviations.Size = New System.Drawing.Size(537, 22)
        Me.ssShowAbbreviations.TabIndex = 15
        Me.ssShowAbbreviations.Text = "StatusStrip1"
        '
        'tsShowAbbreviations
        '
        Me.tsShowAbbreviations.Name = "tsShowAbbreviations"
        Me.tsShowAbbreviations.Size = New System.Drawing.Size(0, 17)
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ClientSize = New System.Drawing.Size(537, 318)
        Me.Controls.Add(Me.ssShowAbbreviations)
        Me.Controls.Add(Me.picFlorida)
        Me.Controls.Add(Me.picAlabama)
        Me.Controls.Add(Me.picGeorgia)
        Me.Controls.Add(Me.picSouthCarolina)
        Me.Controls.Add(Me.picNorthCarolina)
        Me.Controls.Add(Me.picVirginia)
        Me.Controls.Add(Me.lblInstructions)
        Me.Controls.Add(Me.lblShowAbbreviation)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnFlorida)
        Me.Controls.Add(Me.btnAlabama)
        Me.Controls.Add(Me.btnGeorgia)
        Me.Controls.Add(Me.btnSouthCarolina)
        Me.Controls.Add(Me.btnNorthCarolina)
        Me.Controls.Add(Me.btnVirginia)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Form1"
        Me.Text = "State Abbreviations"
        CType(Me.picVirginia, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picNorthCarolina, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSouthCarolina, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGeorgia, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAlabama, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFlorida, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ssShowAbbreviations.ResumeLayout(False)
        Me.ssShowAbbreviations.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnVirginia As Button
    Friend WithEvents btnNorthCarolina As Button
    Friend WithEvents btnSouthCarolina As Button
    Friend WithEvents btnGeorgia As Button
    Friend WithEvents btnAlabama As Button
    Friend WithEvents btnFlorida As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblShowAbbreviation As Label
    Friend WithEvents lblInstructions As Label
    Friend WithEvents picVirginia As PictureBox
    Friend WithEvents picNorthCarolina As PictureBox
    Friend WithEvents picSouthCarolina As PictureBox
    Friend WithEvents picGeorgia As PictureBox
    Friend WithEvents picAlabama As PictureBox
    Friend WithEvents picFlorida As PictureBox
    Friend WithEvents ssShowAbbreviations As StatusStrip
    Friend WithEvents tsShowAbbreviations As ToolStripStatusLabel
End Class
