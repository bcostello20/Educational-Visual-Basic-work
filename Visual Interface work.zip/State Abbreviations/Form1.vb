﻿Public Class Form1
    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Ends the program
        Me.Close()
    End Sub

    Private Sub BtnVirginia_Click(sender As Object, e As EventArgs) Handles btnVirginia.Click
        'Displays the abbreviation for Virginia
        'lblShowAbbreviation.Text = "VA"
        MessageBox.Show("VA")
        picVirginia.Visible = True
        tsShowAbbreviations.Text = "VA"
    End Sub

    Private Sub BtnNorthCarolina_Click(sender As Object, e As EventArgs) Handles btnNorthCarolina.Click
        'Displays the abbreviation for North Carolina
        'lblShowAbbreviation.Text = "NC"
        MessageBox.Show("NC")
        picNorthCarolina.Visible = True
        tsShowAbbreviations.Text = "NC"
    End Sub

    Private Sub BtnSouthCarolina_Click(sender As Object, e As EventArgs) Handles btnSouthCarolina.Click
        'Displays the abbreviation for South Carolina
        'lblShowAbbreviation.Text = "SC"
        MessageBox.Show("SC")
        picSouthCarolina.Visible = True
        tsShowAbbreviations.Text = "SC"
    End Sub

    Private Sub BtnGeorgia_Click(sender As Object, e As EventArgs) Handles btnGeorgia.Click
        'Displays the abbreviation for Georgia
        'lblShowAbbreviation.Text = "GA"
        MessageBox.Show("GA")
        picGeorgia.Visible = True
        tsShowAbbreviations.Text = "GA"
    End Sub

    Private Sub BtnAlabama_Click(sender As Object, e As EventArgs) Handles btnAlabama.Click
        'Displays the abbreviation for Alabama
        'lblShowAbbreviation.Text = "AL"
        MessageBox.Show("AL")
        picAlabama.Visible = True
        tsShowAbbreviations.Text = "AL"
    End Sub

    Private Sub BtnFlorida_Click(sender As Object, e As EventArgs) Handles btnFlorida.Click
        'Displays the abbreviation for Florida
        'lblShowAbbreviation.Text = "FL"
        MessageBox.Show("FL")
        picFlorida.Visible = True
        tsShowAbbreviations.Text = "FL"
    End Sub
End Class
