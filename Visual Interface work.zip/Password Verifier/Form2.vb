﻿Public Class Form2
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        Dim firstForm As New formPasswordVerifier
        Me.Hide()
        firstForm.ShowDialog()
    End Sub
End Class