﻿Public Class formPasswordVerifier

    Private Sub formPasswordVerifier_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Have the Username text box ready to take input before the other text boxes on form load
        txtUsername.Select()
    End Sub

    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim strPassword As String = txtPassword.Text ' The password entered by the user
        Dim strEmail As String = txtUsername.Text ' The username (email) entered by the user

        ' Check to see if the username (email) is valid
        If Not checkEmail(strEmail) Then
            MessageBox.Show("Invalid username/email.")
        End If

        ' Check to see if the password and confirm password are the same then check if the password is valid
        If txtConfirmPassword.Text = txtPassword.Text Then
            ' If the password is valid, tell the user it is valid
            If isValid(strPassword) Then
                MessageBox.Show("Logging in...")
                Dim nextForm As New Form2
                Me.Hide()
                nextForm.ShowDialog()
                ' If the password is invalid, tell the user it is invalid
            Else
                MessageBox.Show("Invalid password.")
            End If
        Else
            MessageBox.Show("Passwords do not match.")
        End If


    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clear the text boxes
        txtUsername.Clear()
        txtPassword.Clear()
        txtConfirmPassword.Clear()

        ' Have the Username text box ready to take input
        txtUsername.Select()
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' End the program
        Me.Close()
    End Sub

    Function isValid(ByVal strPwd As String) As Boolean

        Dim intStrLength As Integer = strPwd.Length ' The length of the password
        Dim blnFlag As Boolean ' Flag 
        Dim blnFlag1 As Boolean ' Is there a number in the password?
        Dim blnFlag2 As Boolean ' Is there an upper case letter in the password?
        Dim blnFlag3 As Boolean ' Is there a lower case letter in the password?
        Dim blnFlag4 As Boolean ' Does the password contain one of these special symbols?: %, #, &

        ' Check if the password is at least 12 characters or greater and contains a number
        If intStrLength >= 12 Then
            For i = 0 To intStrLength - 1
                If IsNumeric(strPwd.Substring(i, 1)) Then
                    blnFlag1 = True
                End If
            Next

            ' Check if the password contains an upper case letter
            For i = 0 To intStrLength - 1
                If Char.IsUpper(CChar(strPwd.Substring(i, 1))) Then
                    blnFlag2 = True
                End If
            Next

            ' Check if the password contains a lower case letter
            For i = 0 To intStrLength - 1
                If Char.IsLower(CChar(strPwd.Substring(i, 1))) Then
                    blnFlag3 = True
                End If
            Next

            ' Check if the password contains one of the special symbols
            For i = 0 To intStrLength - 1
                If strPwd.Substring(i, 1) = "%" Or strPwd.Substring(i, 1) = "#" Or strPwd.Substring(i, 1) = "&" Then
                    blnFlag4 = True
                End If
            Next

            blnFlag = blnFlag1 And blnFlag2 And blnFlag3 And blnFlag4
        End If

        ' Return valid or invalid password
        Return blnFlag
    End Function

    Function checkEmail(ByVal strE As String) As Boolean

        Dim intStrEmailLength As Integer = strE.Length ' The length of the username (email)
        Dim blnResultFlag As Boolean ' Flag
        Dim blnFlag5 As Boolean ' Does the username (email) contain letters?
        Dim blnFlag6 As Boolean ' Does the username (email) contain an '@' symbol?
        Dim blnFlag7 As Boolean ' Does the username (email) contain a '.' symbol?

        ' Check if the username (email) contains letters
        For i = 0 To intStrEmailLength - 1
            If Char.IsLetter(CChar(strE.Substring(i, 1))) Then
                blnFlag5 = True
            End If
        Next

        ' Check if the username (email) contains an '@' symbol
        For i = 0 To intStrEmailLength - 1
            If strE.Substring(i, 1) = "@" Then
                blnFlag6 = True
            End If
        Next

        ' Check if the username (email) contains a '.' symbol
        For i = 0 To intStrEmailLength - 1
            If strE.Substring(i, 1) = "." Then
                blnFlag7 = True
            End If
        Next

        blnResultFlag = blnFlag5 And blnFlag6 And blnFlag7

        ' Return valid or invalid username (email)
        Return blnResultFlag
    End Function

End Class
