﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class formPasswordVerifier
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lblPasswordInstruction = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblUsernameInstruction = New System.Windows.Forms.Label()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.lblConfirmPasswordInstruction = New System.Windows.Forms.Label()
        Me.txtConfirmPassword = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lblPasswordInstruction
        '
        Me.lblPasswordInstruction.AutoSize = True
        Me.lblPasswordInstruction.Location = New System.Drawing.Point(27, 50)
        Me.lblPasswordInstruction.Name = "lblPasswordInstruction"
        Me.lblPasswordInstruction.Size = New System.Drawing.Size(84, 13)
        Me.lblPasswordInstruction.TabIndex = 0
        Me.lblPasswordInstruction.Text = "Enter Password:"
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(114, 47)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(100, 20)
        Me.txtPassword.TabIndex = 1
        '
        'btnLogin
        '
        Me.btnLogin.Location = New System.Drawing.Point(36, 117)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(75, 41)
        Me.btnLogin.TabIndex = 2
        Me.btnLogin.Text = "Login"
        Me.btnLogin.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(123, 117)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 41)
        Me.btnClear.TabIndex = 3
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(80, 164)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 4
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblUsernameInstruction
        '
        Me.lblUsernameInstruction.AutoSize = True
        Me.lblUsernameInstruction.Location = New System.Drawing.Point(25, 24)
        Me.lblUsernameInstruction.Name = "lblUsernameInstruction"
        Me.lblUsernameInstruction.Size = New System.Drawing.Size(86, 13)
        Me.lblUsernameInstruction.TabIndex = 5
        Me.lblUsernameInstruction.Text = "Enter Username:"
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(114, 21)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(100, 20)
        Me.txtUsername.TabIndex = 6
        '
        'lblConfirmPasswordInstruction
        '
        Me.lblConfirmPasswordInstruction.AutoSize = True
        Me.lblConfirmPasswordInstruction.Location = New System.Drawing.Point(17, 84)
        Me.lblConfirmPasswordInstruction.Name = "lblConfirmPasswordInstruction"
        Me.lblConfirmPasswordInstruction.Size = New System.Drawing.Size(94, 13)
        Me.lblConfirmPasswordInstruction.TabIndex = 7
        Me.lblConfirmPasswordInstruction.Text = "Confirm Password:"
        '
        'txtConfirmPassword
        '
        Me.txtConfirmPassword.Location = New System.Drawing.Point(114, 81)
        Me.txtConfirmPassword.Name = "txtConfirmPassword"
        Me.txtConfirmPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtConfirmPassword.Size = New System.Drawing.Size(100, 20)
        Me.txtConfirmPassword.TabIndex = 8
        '
        'formPasswordVerifier
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(235, 200)
        Me.Controls.Add(Me.txtConfirmPassword)
        Me.Controls.Add(Me.lblConfirmPasswordInstruction)
        Me.Controls.Add(Me.txtUsername)
        Me.Controls.Add(Me.lblUsernameInstruction)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnLogin)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.lblPasswordInstruction)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "formPasswordVerifier"
        Me.Text = "Password Verifier"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblPasswordInstruction As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents btnLogin As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblUsernameInstruction As Label
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents lblConfirmPasswordInstruction As Label
    Friend WithEvents txtConfirmPassword As TextBox
End Class
