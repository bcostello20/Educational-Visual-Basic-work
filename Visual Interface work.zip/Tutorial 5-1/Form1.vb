﻿Public Class Form1
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        Dim strInput As String ' Stores the month and year that the user selects

        ' Check to see if nothing is selected when user presses OK
        ' If nothing is selected in either of the list boxes -
        ' display a message box telling the user they must select something
        If (lstMonth.SelectedIndex = -1) Then
            MessageBox.Show("You need to select a month")
        ElseIf (lstYear.SelectedIndex = -1) Then
            MessageBox.Show("You need to select a year")
        Else
            strInput = lstMonth.SelectedItem.ToString() & " " & lstYear.SelectedItem.ToString()
            MessageBox.Show("You selected " & strInput)
        End If
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        ' Deselect everything in the month and year list boxes
        lstMonth.SelectedIndex = -1
        lstYear.SelectedIndex = -1
    End Sub
End Class
