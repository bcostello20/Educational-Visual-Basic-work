﻿Public Class formBurningCalories
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboSpeedChoice.SelectedIndexChanged
        Dim dblSpeed As Double
        Dim intInterval As Integer = 5I
        Dim dblCaloriesBurned As Double
        Const dblLOW_SPEED As Double = 3.5D
        Const dblMEDIUM_SPEED As Double = 4.5D
        Const dblHIGH_SPEED As Double = 6D
        Const intEND As Integer = 30I

        Select Case cboSpeedChoice.Text
            Case "Low"
                dblSpeed = dblLOW_SPEED
            Case "Medium"
                dblSpeed = dblMEDIUM_SPEED
            Case "High"
                dblSpeed = dblHIGH_SPEED
        End Select

        For intBegin As Integer = 10 To intEND Step intInterval
            dblCaloriesBurned += intBegin * dblSpeed
            lstCaloriesBurned.Items.Add(dblCaloriesBurned.ToString())
        Next


    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' End the program
        Me.Close()
    End Sub
End Class
