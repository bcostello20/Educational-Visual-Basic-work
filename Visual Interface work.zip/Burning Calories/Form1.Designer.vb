﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formBurningCalories
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cboSpeedChoice = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lstCaloriesBurned = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'cboSpeedChoice
        '
        Me.cboSpeedChoice.FormattingEnabled = True
        Me.cboSpeedChoice.Items.AddRange(New Object() {"Low", "Medium", "High"})
        Me.cboSpeedChoice.Location = New System.Drawing.Point(12, 39)
        Me.cboSpeedChoice.Name = "cboSpeedChoice"
        Me.cboSpeedChoice.Size = New System.Drawing.Size(121, 21)
        Me.cboSpeedChoice.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Select your speed"
        '
        'lstCaloriesBurned
        '
        Me.lstCaloriesBurned.FormattingEnabled = True
        Me.lstCaloriesBurned.Location = New System.Drawing.Point(184, 39)
        Me.lstCaloriesBurned.Name = "lstCaloriesBurned"
        Me.lstCaloriesBurned.Size = New System.Drawing.Size(120, 95)
        Me.lstCaloriesBurned.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(204, 23)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(81, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Calories Burned"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(118, 199)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 4
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'formBurningCalories
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(315, 234)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lstCaloriesBurned)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cboSpeedChoice)
        Me.Name = "formBurningCalories"
        Me.Text = "Burning Calories"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cboSpeedChoice As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents lstCaloriesBurned As ListBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btnExit As Button
End Class
