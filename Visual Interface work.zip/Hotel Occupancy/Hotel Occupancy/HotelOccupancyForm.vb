﻿Public Class HotelOccupancyForm
    Const intSIZE = 29 ' Size for the array
    Dim occupancyCount(intSIZE) ' The array of 30 elements
    ' Dim intFloor As Integer = CInt(cboFloor.Text)
    Dim intOccupied As Integer

    Private Sub btnTotals_Click(sender As Object, e As EventArgs) Handles btnTotals.Click

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clear the labels and list box
        lblOccupancyRate.Text = String.Empty
        lblRoomsOccupied.Text = String.Empty
        lstRoomOccupancyData.Items.Clear()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' End the program
        Me.Close()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

    End Sub
End Class
