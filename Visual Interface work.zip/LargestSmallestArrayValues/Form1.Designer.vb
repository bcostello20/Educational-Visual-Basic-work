﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLargestSmallestValues
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnInputIntegers = New System.Windows.Forms.Button()
        Me.btnMinMax = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.lstValues = New System.Windows.Forms.ListBox()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnInputIntegers
        '
        Me.btnInputIntegers.Location = New System.Drawing.Point(12, 12)
        Me.btnInputIntegers.Name = "btnInputIntegers"
        Me.btnInputIntegers.Size = New System.Drawing.Size(154, 23)
        Me.btnInputIntegers.TabIndex = 0
        Me.btnInputIntegers.Text = "Step 1: Input the Integers"
        Me.btnInputIntegers.UseVisualStyleBackColor = True
        '
        'btnMinMax
        '
        Me.btnMinMax.Location = New System.Drawing.Point(12, 52)
        Me.btnMinMax.Name = "btnMinMax"
        Me.btnMinMax.Size = New System.Drawing.Size(154, 23)
        Me.btnMinMax.TabIndex = 1
        Me.btnMinMax.Text = "Step 2: Display Min and Max"
        Me.btnMinMax.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(13, 98)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(51, 26)
        Me.btnClear.TabIndex = 2
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'lstValues
        '
        Me.lstValues.FormattingEnabled = True
        Me.lstValues.Items.AddRange(New Object() {"Input Values"})
        Me.lstValues.Location = New System.Drawing.Point(195, 12)
        Me.lstValues.Name = "lstValues"
        Me.lstValues.Size = New System.Drawing.Size(118, 121)
        Me.lstValues.TabIndex = 3
        '
        'lblMessage
        '
        Me.lblMessage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMessage.Location = New System.Drawing.Point(12, 168)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(301, 23)
        Me.lblMessage.TabIndex = 4
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(70, 98)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(51, 26)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmLargestSmallestValues
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(326, 203)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblMessage)
        Me.Controls.Add(Me.lstValues)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnMinMax)
        Me.Controls.Add(Me.btnInputIntegers)
        Me.Name = "frmLargestSmallestValues"
        Me.Text = "Largest / Smallest Values"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnInputIntegers As Button
    Friend WithEvents btnMinMax As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents lstValues As ListBox
    Friend WithEvents lblMessage As Label
    Friend WithEvents btnExit As Button
End Class
