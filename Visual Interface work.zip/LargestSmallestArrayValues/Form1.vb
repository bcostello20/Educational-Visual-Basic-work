﻿Public Class frmLargestSmallestValues

    ' Member Variables
    Const intMAX_VALUES As Integer = 9 ' The max number of values to be entered by the user
    Dim intValues(intMAX_VALUES) As Integer ' The integer array to hold the values
    Dim intCount As Integer ' Loop counter
    Dim largestNum As Integer ' The largest number in the array
    Dim smallestNum As Integer ' The smallest number in the array

    Private Sub BtnInputIntegers_Click(sender As Object, e As EventArgs) Handles btnInputIntegers.Click

        ' Instruction for the user
        MessageBox.Show("You will be asked to enter 10 numbers into an array")

        ' Get the numbers and store them in the array
        For intCount = 0 To intMAX_VALUES
            intValues(intCount) = CInt(InputBox("Enter a number"))
        Next

        ' Display the array contents in the list box
        For intCount = 0 To intMAX_VALUES
            lstValues.Items.Add(intValues(intCount))
        Next

        ' Get the largest number in the array
        Dim num As Integer ' The temp variable to hold smaller values
        For intCount = 0 To intMAX_VALUES
            If intValues(intCount) > num Then
                num = intValues(intCount)
            End If
        Next
        largestNum = num

        ' Get the smallest number in the array
        Dim num2 As Integer = intMAX_VALUES ' The temp variable to hold larger values
        For intCount = 0 To intMAX_VALUES
            If intValues(intCount) < num2 Then
                num2 = intValues(intCount)
            End If
        Next
        smallestNum = num2

    End Sub

    Private Sub BtnMinMax_Click(sender As Object, e As EventArgs) Handles btnMinMax.Click
        ' Display the largest and smallest numbers in the array
        lblMessage.Text = "The largest value is " & largestNum & " and the smallest value is " & smallestNum
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Empty the list box and the label
        lstValues.Items.Clear()
        lblMessage.Text = String.Empty
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' End the program
        Me.Close()
    End Sub
End Class
