﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOrder))
        Me.pcbTree = New System.Windows.Forms.PictureBox()
        Me.pcbRed1 = New System.Windows.Forms.PictureBox()
        Me.pcbRed3 = New System.Windows.Forms.PictureBox()
        Me.pcbRed2 = New System.Windows.Forms.PictureBox()
        Me.pcbRed5 = New System.Windows.Forms.PictureBox()
        Me.pcbRed4 = New System.Windows.Forms.PictureBox()
        Me.pcbYellow3 = New System.Windows.Forms.PictureBox()
        Me.pcbYellow4 = New System.Windows.Forms.PictureBox()
        Me.pcbYellow5 = New System.Windows.Forms.PictureBox()
        Me.pcbYellow2 = New System.Windows.Forms.PictureBox()
        Me.pcbYellow1 = New System.Windows.Forms.PictureBox()
        Me.tmrSeconds = New System.Windows.Forms.Timer(Me.components)
        Me.mnuOrderForm = New System.Windows.Forms.MenuStrip()
        Me.PlaceOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearcOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtOrderID = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmbTreeType = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtQuantity = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dtpOrderDate = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtPerson = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.dtpPickUp = New System.Windows.Forms.DateTimePicker()
        Me.grpOrder = New System.Windows.Forms.GroupBox()
        CType(Me.pcbTree, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbRed1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbRed3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbRed2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbRed5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbRed4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbYellow3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbYellow4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbYellow5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbYellow2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbYellow1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.mnuOrderForm.SuspendLayout()
        Me.grpOrder.SuspendLayout()
        Me.SuspendLayout()
        '
        'pcbTree
        '
        Me.pcbTree.Image = CType(resources.GetObject("pcbTree.Image"), System.Drawing.Image)
        Me.pcbTree.Location = New System.Drawing.Point(538, 31)
        Me.pcbTree.Name = "pcbTree"
        Me.pcbTree.Size = New System.Drawing.Size(182, 280)
        Me.pcbTree.TabIndex = 0
        Me.pcbTree.TabStop = False
        '
        'pcbRed1
        '
        Me.pcbRed1.Image = CType(resources.GetObject("pcbRed1.Image"), System.Drawing.Image)
        Me.pcbRed1.Location = New System.Drawing.Point(609, 102)
        Me.pcbRed1.Name = "pcbRed1"
        Me.pcbRed1.Size = New System.Drawing.Size(10, 10)
        Me.pcbRed1.TabIndex = 1
        Me.pcbRed1.TabStop = False
        Me.pcbRed1.Visible = False
        '
        'pcbRed3
        '
        Me.pcbRed3.Image = CType(resources.GetObject("pcbRed3.Image"), System.Drawing.Image)
        Me.pcbRed3.Location = New System.Drawing.Point(594, 205)
        Me.pcbRed3.Name = "pcbRed3"
        Me.pcbRed3.Size = New System.Drawing.Size(10, 10)
        Me.pcbRed3.TabIndex = 2
        Me.pcbRed3.TabStop = False
        Me.pcbRed3.Visible = False
        '
        'pcbRed2
        '
        Me.pcbRed2.Image = CType(resources.GetObject("pcbRed2.Image"), System.Drawing.Image)
        Me.pcbRed2.Location = New System.Drawing.Point(609, 159)
        Me.pcbRed2.Name = "pcbRed2"
        Me.pcbRed2.Size = New System.Drawing.Size(10, 10)
        Me.pcbRed2.TabIndex = 3
        Me.pcbRed2.TabStop = False
        Me.pcbRed2.Visible = False
        '
        'pcbRed5
        '
        Me.pcbRed5.Image = CType(resources.GetObject("pcbRed5.Image"), System.Drawing.Image)
        Me.pcbRed5.Location = New System.Drawing.Point(663, 224)
        Me.pcbRed5.Name = "pcbRed5"
        Me.pcbRed5.Size = New System.Drawing.Size(10, 10)
        Me.pcbRed5.TabIndex = 4
        Me.pcbRed5.TabStop = False
        Me.pcbRed5.Visible = False
        '
        'pcbRed4
        '
        Me.pcbRed4.Image = CType(resources.GetObject("pcbRed4.Image"), System.Drawing.Image)
        Me.pcbRed4.Location = New System.Drawing.Point(649, 168)
        Me.pcbRed4.Name = "pcbRed4"
        Me.pcbRed4.Size = New System.Drawing.Size(11, 10)
        Me.pcbRed4.TabIndex = 5
        Me.pcbRed4.TabStop = False
        Me.pcbRed4.Visible = False
        '
        'pcbYellow3
        '
        Me.pcbYellow3.Image = CType(resources.GetObject("pcbYellow3.Image"), System.Drawing.Image)
        Me.pcbYellow3.Location = New System.Drawing.Point(570, 241)
        Me.pcbYellow3.Name = "pcbYellow3"
        Me.pcbYellow3.Size = New System.Drawing.Size(11, 13)
        Me.pcbYellow3.TabIndex = 6
        Me.pcbYellow3.TabStop = False
        '
        'pcbYellow4
        '
        Me.pcbYellow4.Image = CType(resources.GetObject("pcbYellow4.Image"), System.Drawing.Image)
        Me.pcbYellow4.Location = New System.Drawing.Point(620, 184)
        Me.pcbYellow4.Name = "pcbYellow4"
        Me.pcbYellow4.Size = New System.Drawing.Size(12, 11)
        Me.pcbYellow4.TabIndex = 7
        Me.pcbYellow4.TabStop = False
        '
        'pcbYellow5
        '
        Me.pcbYellow5.Image = CType(resources.GetObject("pcbYellow5.Image"), System.Drawing.Image)
        Me.pcbYellow5.Location = New System.Drawing.Point(620, 241)
        Me.pcbYellow5.Name = "pcbYellow5"
        Me.pcbYellow5.Size = New System.Drawing.Size(13, 13)
        Me.pcbYellow5.TabIndex = 8
        Me.pcbYellow5.TabStop = False
        '
        'pcbYellow2
        '
        Me.pcbYellow2.Image = CType(resources.GetObject("pcbYellow2.Image"), System.Drawing.Image)
        Me.pcbYellow2.Location = New System.Drawing.Point(594, 131)
        Me.pcbYellow2.Name = "pcbYellow2"
        Me.pcbYellow2.Size = New System.Drawing.Size(11, 10)
        Me.pcbYellow2.TabIndex = 9
        Me.pcbYellow2.TabStop = False
        '
        'pcbYellow1
        '
        Me.pcbYellow1.Image = CType(resources.GetObject("pcbYellow1.Image"), System.Drawing.Image)
        Me.pcbYellow1.Location = New System.Drawing.Point(641, 120)
        Me.pcbYellow1.Name = "pcbYellow1"
        Me.pcbYellow1.Size = New System.Drawing.Size(10, 10)
        Me.pcbYellow1.TabIndex = 10
        Me.pcbYellow1.TabStop = False
        '
        'tmrSeconds
        '
        Me.tmrSeconds.Enabled = True
        Me.tmrSeconds.Interval = 1000
        '
        'mnuOrderForm
        '
        Me.mnuOrderForm.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PlaceOrderToolStripMenuItem, Me.SearcOrderToolStripMenuItem})
        Me.mnuOrderForm.Location = New System.Drawing.Point(0, 0)
        Me.mnuOrderForm.Name = "mnuOrderForm"
        Me.mnuOrderForm.Size = New System.Drawing.Size(777, 24)
        Me.mnuOrderForm.TabIndex = 11
        '
        'PlaceOrderToolStripMenuItem
        '
        Me.PlaceOrderToolStripMenuItem.Name = "PlaceOrderToolStripMenuItem"
        Me.PlaceOrderToolStripMenuItem.Size = New System.Drawing.Size(80, 20)
        Me.PlaceOrderToolStripMenuItem.Text = "Place Order"
        '
        'SearcOrderToolStripMenuItem
        '
        Me.SearcOrderToolStripMenuItem.Name = "SearcOrderToolStripMenuItem"
        Me.SearcOrderToolStripMenuItem.Size = New System.Drawing.Size(87, 20)
        Me.SearcOrderToolStripMenuItem.Text = "Search Order"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(69, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 13)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "OrderID:"
        '
        'txtOrderID
        '
        Me.txtOrderID.Location = New System.Drawing.Point(117, 31)
        Me.txtOrderID.Name = "txtOrderID"
        Me.txtOrderID.Size = New System.Drawing.Size(215, 20)
        Me.txtOrderID.TabIndex = 13
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(54, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 13)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Tree Type: "
        '
        'cmbTreeType
        '
        Me.cmbTreeType.FormattingEnabled = True
        Me.cmbTreeType.Items.AddRange(New Object() {"Blue Spruce", "Concolor Fir", "Douglas Fir", "Fraser"})
        Me.cmbTreeType.Location = New System.Drawing.Point(117, 64)
        Me.cmbTreeType.Name = "cmbTreeType"
        Me.cmbTreeType.Size = New System.Drawing.Size(215, 21)
        Me.cmbTreeType.TabIndex = 16
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(41, 99)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 13)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Tree Quantity:"
        '
        'txtQuantity
        '
        Me.txtQuantity.Location = New System.Drawing.Point(117, 95)
        Me.txtQuantity.Name = "txtQuantity"
        Me.txtQuantity.Size = New System.Drawing.Size(215, 20)
        Me.txtQuantity.TabIndex = 18
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(50, 129)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 13)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Order Date: "
        '
        'dtpOrderDate
        '
        Me.dtpOrderDate.Location = New System.Drawing.Point(117, 123)
        Me.dtpOrderDate.Name = "dtpOrderDate"
        Me.dtpOrderDate.Size = New System.Drawing.Size(215, 20)
        Me.dtpOrderDate.TabIndex = 20
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(43, 163)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 13)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Sales Person:"
        '
        'txtPerson
        '
        Me.txtPerson.Location = New System.Drawing.Point(117, 160)
        Me.txtPerson.Name = "txtPerson"
        Me.txtPerson.Size = New System.Drawing.Size(215, 20)
        Me.txtPerson.TabIndex = 22
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(36, 202)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(74, 13)
        Me.Label6.TabIndex = 23
        Me.Label6.Text = "Pick Up Date:"
        '
        'dtpPickUp
        '
        Me.dtpPickUp.Location = New System.Drawing.Point(116, 196)
        Me.dtpPickUp.Name = "dtpPickUp"
        Me.dtpPickUp.Size = New System.Drawing.Size(216, 20)
        Me.dtpPickUp.TabIndex = 24
        '
        'grpOrder
        '
        Me.grpOrder.Controls.Add(Me.dtpPickUp)
        Me.grpOrder.Controls.Add(Me.Label6)
        Me.grpOrder.Controls.Add(Me.txtPerson)
        Me.grpOrder.Controls.Add(Me.Label5)
        Me.grpOrder.Controls.Add(Me.dtpOrderDate)
        Me.grpOrder.Controls.Add(Me.Label4)
        Me.grpOrder.Controls.Add(Me.txtQuantity)
        Me.grpOrder.Controls.Add(Me.Label3)
        Me.grpOrder.Controls.Add(Me.cmbTreeType)
        Me.grpOrder.Controls.Add(Me.Label2)
        Me.grpOrder.Controls.Add(Me.txtOrderID)
        Me.grpOrder.Controls.Add(Me.Label1)
        Me.grpOrder.Location = New System.Drawing.Point(44, 50)
        Me.grpOrder.Name = "grpOrder"
        Me.grpOrder.Size = New System.Drawing.Size(388, 243)
        Me.grpOrder.TabIndex = 25
        Me.grpOrder.TabStop = False
        Me.grpOrder.Text = "Order"
        '
        'frmOrder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(777, 323)
        Me.Controls.Add(Me.grpOrder)
        Me.Controls.Add(Me.pcbYellow1)
        Me.Controls.Add(Me.pcbYellow2)
        Me.Controls.Add(Me.pcbYellow5)
        Me.Controls.Add(Me.pcbYellow4)
        Me.Controls.Add(Me.pcbYellow3)
        Me.Controls.Add(Me.pcbRed4)
        Me.Controls.Add(Me.pcbRed5)
        Me.Controls.Add(Me.pcbRed2)
        Me.Controls.Add(Me.pcbRed3)
        Me.Controls.Add(Me.pcbRed1)
        Me.Controls.Add(Me.pcbTree)
        Me.Controls.Add(Me.mnuOrderForm)
        Me.MainMenuStrip = Me.mnuOrderForm
        Me.Name = "frmOrder"
        Me.Text = "Order Form"
        CType(Me.pcbTree, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbRed1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbRed3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbRed2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbRed5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbRed4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbYellow3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbYellow4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbYellow5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbYellow2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbYellow1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.mnuOrderForm.ResumeLayout(False)
        Me.mnuOrderForm.PerformLayout()
        Me.grpOrder.ResumeLayout(False)
        Me.grpOrder.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    ' Friend WithEvents XmasTreeDatabaseDataSet1 As XmasTreeDatabaseDataSet
    Friend WithEvents pcbTree As PictureBox
    Friend WithEvents pcbRed1 As PictureBox
    Friend WithEvents pcbRed3 As PictureBox
    Friend WithEvents pcbRed2 As PictureBox
    Friend WithEvents pcbRed5 As PictureBox
    Friend WithEvents pcbRed4 As PictureBox
    Friend WithEvents pcbYellow3 As PictureBox
    Friend WithEvents pcbYellow4 As PictureBox
    Friend WithEvents pcbYellow5 As PictureBox
    Friend WithEvents pcbYellow2 As PictureBox
    Friend WithEvents pcbYellow1 As PictureBox
    Friend WithEvents tmrSeconds As Timer
    Friend WithEvents mnuOrderForm As MenuStrip
    Friend WithEvents PlaceOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SearcOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label1 As Label
    Friend WithEvents txtOrderID As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents cmbTreeType As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtQuantity As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents dtpOrderDate As DateTimePicker
    Friend WithEvents Label5 As Label
    Friend WithEvents txtPerson As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents dtpPickUp As DateTimePicker
    Friend WithEvents grpOrder As GroupBox
End Class
