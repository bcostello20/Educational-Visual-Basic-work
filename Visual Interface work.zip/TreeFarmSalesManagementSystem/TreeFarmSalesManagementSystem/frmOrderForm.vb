﻿Imports System.IO
Public Class frmOrder

    Private intSeconds As Integer
    Const strFILENAME As String = "record.txt"

    ' Order structure
    Structure Order
        Dim strOrderID As String
        Dim strTreeType As String
        Dim intTreeQuantity As Integer
        Dim orderDate As Date
        Dim strSalesPerson As String
        Dim pickupDate As Date
    End Structure

    Private Sub PlaceOrderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PlaceOrderToolStripMenuItem.Click
        Dim order As New Order

        With order
            .strOrderID = txtOrderID.Text
            .strTreeType = cmbTreeType.Text
            .intTreeQuantity = CInt(txtQuantity.Text)
            .orderDate = dtpOrderDate.Value
            .strSalesPerson = txtPerson.Text
            .pickupDate = dtpPickUp.Value
        End With

        ' Save the record to a text file
        Dim recordFile As StreamWriter

        ' Check if the file already exists
        If File.Exists(strFILENAME) Then
            ' Open up the file
            recordFile = File.AppendText(strFILENAME)
        Else
            ' The file does not exist, create one
            recordFile = File.CreateText(strFILENAME)
        End If

        ' Write the record to the file
        recordFile.WriteLine(order.strOrderID)
        recordFile.WriteLine(order.strTreeType)
        recordFile.WriteLine(order.intTreeQuantity)
        recordFile.WriteLine(order.orderDate)
        recordFile.WriteLine(order.strSalesPerson)
        recordFile.WriteLine(order.pickupDate)

        ' Close the file
        recordFile.Close()

        ' Clear the order form
        ClearOrderForm()
    End Sub

    ' Purpose: to clear the order form after writing the record to a text file
    Sub ClearOrderForm()
        txtOrderID.Clear()
        cmbTreeType.Text = String.Empty
        txtQuantity.Clear()
        txtPerson.Clear()

        ' Focus on the first field
        txtOrderID.Focus()
    End Sub

    Private Sub SearcOrderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearcOrderToolStripMenuItem.Click
        If txtOrderID.Text = String.Empty Then
            Dim getOrderID = InputBox("Enter an Order ID.")
            txtOrderID.Text = getOrderID
        End If

        Dim order As New Order
        Dim blnFoundRecord As Boolean = False
        Dim recordFile As StreamReader

        ' Check if file exists
        If File.Exists(strFILENAME) Then
            ' Open up the file
            recordFile = File.OpenText(strFILENAME)

            ' Search through the records
            Do Until recordFile.Peek = -1 Or blnFoundRecord
                ' Read the next record
                order.strOrderID = recordFile.ReadLine
                order.strTreeType = recordFile.ReadLine
                order.intTreeQuantity = CInt(recordFile.ReadLine)
                order.orderDate = Convert.ToDateTime(recordFile.ReadLine)
                order.strSalesPerson = recordFile.ReadLine
                order.pickupDate = Convert.ToDateTime(recordFile.ReadLine)

                ' Is this the order we are looking for?
                If txtOrderID.Text = order.strOrderID Then
                    blnFoundRecord = True
                End If
            Loop

            ' Close the file
            recordFile.Close()

            If blnFoundRecord Then
                ' We found the order record
                txtOrderID.Text = order.strOrderID
                cmbTreeType.Text = order.strTreeType
                txtQuantity.Text = order.intTreeQuantity.ToString()
                dtpOrderDate.Value = order.orderDate
                txtPerson.Text = order.strSalesPerson
                dtpPickUp.Value = order.pickupDate
            Else
                ' No match
                MessageBox.Show(txtOrderID.Text & " was not found.", "Record Not Found")
            End If
        Else
            ' Error attempting to open file
            MessageBox.Show("File cannot be opened.", "Error")

        End If

    End Sub

    Private Sub tmrSeconds_Tick(sender As Object, e As EventArgs) Handles tmrSeconds.Tick
        OnTimedEvent()
    End Sub

    ' Purpose: To alternate the visiblity of the colored squares on the tree to make them appear as flashing
    Private Sub OnTimedEvent()
        pcbRed1.Visible = Not pcbRed1.Visible
        pcbRed2.Visible = Not pcbRed2.Visible
        pcbRed3.Visible = Not pcbRed3.Visible
        pcbRed4.Visible = Not pcbRed4.Visible
        pcbRed5.Visible = Not pcbRed5.Visible

        pcbYellow1.Visible = Not pcbYellow1.Visible
        pcbYellow2.Visible = Not pcbYellow2.Visible
        pcbYellow3.Visible = Not pcbYellow3.Visible
        pcbYellow4.Visible = Not pcbYellow4.Visible
        pcbYellow5.Visible = Not pcbYellow5.Visible
    End Sub
End Class