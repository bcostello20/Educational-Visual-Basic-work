﻿Public Class frmTreeFarm
    Private Sub frmTreeFarm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'XmasTreeDatabaseDataSet.Tree' table. You can move, or remove it, as needed.
        Me.TreeTableAdapter.Fill(Me.XmasTreeDatabaseDataSet.Tree)

    End Sub

    Private Sub TreeBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles TreeBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.TreeBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.XmasTreeDatabaseDataSet)

    End Sub

    Private Sub mnuInventory_Click(sender As Object, e As EventArgs) Handles mnuInventory.Click
        TreeDataGridView.Visible = True
        TreeBindingNavigator.Visible = True
    End Sub

    Private Sub mnuOrder_Click(sender As Object, e As EventArgs) Handles mnuOrder.Click
        Dim frmOrder As New frmOrder
        frmOrder.Show()
    End Sub

    Private Sub mnuCustomer_Click(sender As Object, e As EventArgs) Handles mnuCustomer.Click
        Dim frmCustomer As New frmCustomer
        frmCustomer.Show()
    End Sub
End Class
