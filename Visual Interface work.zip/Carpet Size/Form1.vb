﻿Public Class Form1
    Dim area
    Private Sub BtnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        area = txtLength.Text * txtWidth.Text
        lblDisplayArea.Text = area
    End Sub

    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class
