﻿Public Class formRandomNumberGuessingGame
    Private Sub BtnRandomNumber_Click(sender As Object, e As EventArgs) Handles btnRandomNumber.Click
        ' Member variables
        Dim intGuess As Integer ' The user's random number guess
        Dim intRand As Integer ' The random number
        Dim intGuessAmount As Integer ' The number of guesses the user has made 

        ' Create the Random Object
        Dim rand As New Random
        intRand = rand.Next(100) + 1

        ' Convert the user's number guess to an Integer
        intGuess = CInt(txtGuessNumber.Text)

        ' Loop until the user guesses the right number
        Do While intGuess <> intRand
            If intGuess > intRand Then
                MessageBox.Show("Too high, try again.")
                intGuessAmount += 1
                Integer.TryParse(InputBox("Enter number again"), intGuess)
            ElseIf intGuess < intRand Then
                MessageBox.Show("Too low, try again.")
                intGuessAmount += 1
                Integer.TryParse(InputBox("Enter number again"), intGuess)
            End If
        Loop

        ' Tell the user they guessed the correct number and the number of guesses they made
        If intGuess = intRand Then
            MessageBox.Show("You got it!" & " Total Guesses: " & intGuessAmount.ToString())
        End If
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' End the program
        Me.Close()
    End Sub
End Class
