﻿Public Class formSoftwareSales
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        ' Member variables
        Dim dectotalLicensing As Decimal ' The total for licensing options
        Dim dectotalFeatures As Decimal ' The total for optional features
        Const decYEARLY_LICENSE_PRICE As Decimal = 5000D ' The price for a yearly license
        Const decONE_TIME_PURCHASE_PRICE As Decimal = 20000D ' The price for a one-time purchase
        Const decLEVEL_3_TECHNICAL_SUPPORT_PRICE As Decimal = 3500D ' The price for level-3 technical support
        Const decON_SITE_TRAINING_PRICE As Decimal = 2000D ' The price for on-site training
        Const decCLOUD_BACKUP_PRICE As Decimal = 300D ' The price for cloud backup

        ' Find out which radio button is selected and add the price to the licensing total
        If rbYearlyLicense.Checked Then
            dectotalLicensing = decYEARLY_LICENSE_PRICE
        ElseIf rbOneTimePurchase.Checked Then
            dectotalLicensing = decONE_TIME_PURCHASE_PRICE
        End If

        ' Find out which check boxes are checked and add the price to the features total
        If cbTechnicalSupport.Checked = True Then
            dectotalFeatures += decLEVEL_3_TECHNICAL_SUPPORT_PRICE
        End If
        If cbTraining.Checked = True Then
            dectotalFeatures += decON_SITE_TRAINING_PRICE
        End If
        If cbCloudBackup.Checked = True Then
            dectotalFeatures += decCLOUD_BACKUP_PRICE
        End If

        ' Display the total licensing price on the screen for the user
        lblDisplaySoftwareCost.Text = (dectotalLicensing.ToString("c"))

        ' Display the total features price on the screen for the user
        lblDisplayFeaturesCost.Text = (dectotalFeatures.ToString("c"))

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Uncheck the check boxes that are checked
        cbTechnicalSupport.Checked = False
        cbTraining.Checked = False
        cbCloudBackup.Checked = False

        ' Clear the radio button that is selected
        rbYearlyLicense.Checked = False
        rbOneTimePurchase.Checked = False

        ' Clear the total price labels
        lblDisplaySoftwareCost.Text = String.Empty
        lblDisplayFeaturesCost.Text = String.Empty
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        ' End the program
        Me.Close()
    End Sub
End Class
