﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formSoftwareSales
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbLicensingOptions = New System.Windows.Forms.GroupBox()
        Me.rbOneTimePurchase = New System.Windows.Forms.RadioButton()
        Me.rbYearlyLicense = New System.Windows.Forms.RadioButton()
        Me.gbOptionalFeatures = New System.Windows.Forms.GroupBox()
        Me.cbCloudBackup = New System.Windows.Forms.CheckBox()
        Me.cbTraining = New System.Windows.Forms.CheckBox()
        Me.cbTechnicalSupport = New System.Windows.Forms.CheckBox()
        Me.gbTotalCosts = New System.Windows.Forms.GroupBox()
        Me.lblDisplayFeaturesCost = New System.Windows.Forms.Label()
        Me.lblDisplaySoftwareCost = New System.Windows.Forms.Label()
        Me.lblCostOfFeatures = New System.Windows.Forms.Label()
        Me.lblCostOfSoftware = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.gbLicensingOptions.SuspendLayout()
        Me.gbOptionalFeatures.SuspendLayout()
        Me.gbTotalCosts.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbLicensingOptions
        '
        Me.gbLicensingOptions.Controls.Add(Me.rbOneTimePurchase)
        Me.gbLicensingOptions.Controls.Add(Me.rbYearlyLicense)
        Me.gbLicensingOptions.Location = New System.Drawing.Point(28, 29)
        Me.gbLicensingOptions.Name = "gbLicensingOptions"
        Me.gbLicensingOptions.Size = New System.Drawing.Size(241, 137)
        Me.gbLicensingOptions.TabIndex = 0
        Me.gbLicensingOptions.TabStop = False
        Me.gbLicensingOptions.Text = "Licensing Options"
        '
        'rbOneTimePurchase
        '
        Me.rbOneTimePurchase.AutoSize = True
        Me.rbOneTimePurchase.Location = New System.Drawing.Point(27, 86)
        Me.rbOneTimePurchase.Name = "rbOneTimePurchase"
        Me.rbOneTimePurchase.Size = New System.Drawing.Size(156, 21)
        Me.rbOneTimePurchase.TabIndex = 1
        Me.rbOneTimePurchase.Text = "One-Time Purchase"
        Me.rbOneTimePurchase.UseVisualStyleBackColor = True
        '
        'rbYearlyLicense
        '
        Me.rbYearlyLicense.AutoSize = True
        Me.rbYearlyLicense.Location = New System.Drawing.Point(27, 35)
        Me.rbYearlyLicense.Name = "rbYearlyLicense"
        Me.rbYearlyLicense.Size = New System.Drawing.Size(117, 21)
        Me.rbYearlyLicense.TabIndex = 0
        Me.rbYearlyLicense.Text = "Yearly license"
        Me.rbYearlyLicense.UseVisualStyleBackColor = True
        '
        'gbOptionalFeatures
        '
        Me.gbOptionalFeatures.Controls.Add(Me.cbCloudBackup)
        Me.gbOptionalFeatures.Controls.Add(Me.cbTraining)
        Me.gbOptionalFeatures.Controls.Add(Me.cbTechnicalSupport)
        Me.gbOptionalFeatures.Location = New System.Drawing.Point(395, 29)
        Me.gbOptionalFeatures.Name = "gbOptionalFeatures"
        Me.gbOptionalFeatures.Size = New System.Drawing.Size(358, 137)
        Me.gbOptionalFeatures.TabIndex = 1
        Me.gbOptionalFeatures.TabStop = False
        Me.gbOptionalFeatures.Text = "Optional Features (yearly)"
        '
        'cbCloudBackup
        '
        Me.cbCloudBackup.AutoSize = True
        Me.cbCloudBackup.Location = New System.Drawing.Point(36, 110)
        Me.cbCloudBackup.Name = "cbCloudBackup"
        Me.cbCloudBackup.Size = New System.Drawing.Size(117, 21)
        Me.cbCloudBackup.TabIndex = 2
        Me.cbCloudBackup.Text = "Cloud Backup"
        Me.cbCloudBackup.UseVisualStyleBackColor = True
        '
        'cbTraining
        '
        Me.cbTraining.AutoSize = True
        Me.cbTraining.Location = New System.Drawing.Point(36, 72)
        Me.cbTraining.Name = "cbTraining"
        Me.cbTraining.Size = New System.Drawing.Size(132, 21)
        Me.cbTraining.TabIndex = 1
        Me.cbTraining.Text = "On-site Training"
        Me.cbTraining.UseVisualStyleBackColor = True
        '
        'cbTechnicalSupport
        '
        Me.cbTechnicalSupport.AutoSize = True
        Me.cbTechnicalSupport.Location = New System.Drawing.Point(36, 35)
        Me.cbTechnicalSupport.Name = "cbTechnicalSupport"
        Me.cbTechnicalSupport.Size = New System.Drawing.Size(196, 21)
        Me.cbTechnicalSupport.TabIndex = 0
        Me.cbTechnicalSupport.Text = "Level-3 Technical Support"
        Me.cbTechnicalSupport.UseVisualStyleBackColor = True
        '
        'gbTotalCosts
        '
        Me.gbTotalCosts.Controls.Add(Me.lblDisplayFeaturesCost)
        Me.gbTotalCosts.Controls.Add(Me.lblDisplaySoftwareCost)
        Me.gbTotalCosts.Controls.Add(Me.lblCostOfFeatures)
        Me.gbTotalCosts.Controls.Add(Me.lblCostOfSoftware)
        Me.gbTotalCosts.Location = New System.Drawing.Point(174, 205)
        Me.gbTotalCosts.Name = "gbTotalCosts"
        Me.gbTotalCosts.Size = New System.Drawing.Size(426, 124)
        Me.gbTotalCosts.TabIndex = 2
        Me.gbTotalCosts.TabStop = False
        '
        'lblDisplayFeaturesCost
        '
        Me.lblDisplayFeaturesCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisplayFeaturesCost.Location = New System.Drawing.Point(257, 75)
        Me.lblDisplayFeaturesCost.Name = "lblDisplayFeaturesCost"
        Me.lblDisplayFeaturesCost.Size = New System.Drawing.Size(100, 23)
        Me.lblDisplayFeaturesCost.TabIndex = 3
        '
        'lblDisplaySoftwareCost
        '
        Me.lblDisplaySoftwareCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisplaySoftwareCost.Location = New System.Drawing.Point(257, 22)
        Me.lblDisplaySoftwareCost.Name = "lblDisplaySoftwareCost"
        Me.lblDisplaySoftwareCost.Size = New System.Drawing.Size(100, 23)
        Me.lblDisplaySoftwareCost.TabIndex = 2
        '
        'lblCostOfFeatures
        '
        Me.lblCostOfFeatures.AutoSize = True
        Me.lblCostOfFeatures.Location = New System.Drawing.Point(35, 76)
        Me.lblCostOfFeatures.Name = "lblCostOfFeatures"
        Me.lblCostOfFeatures.Size = New System.Drawing.Size(166, 17)
        Me.lblCostOfFeatures.TabIndex = 1
        Me.lblCostOfFeatures.Text = "Cost of optional features:"
        '
        'lblCostOfSoftware
        '
        Me.lblCostOfSoftware.AutoSize = True
        Me.lblCostOfSoftware.Location = New System.Drawing.Point(32, 22)
        Me.lblCostOfSoftware.Name = "lblCostOfSoftware"
        Me.lblCostOfSoftware.Size = New System.Drawing.Size(172, 17)
        Me.lblCostOfSoftware.TabIndex = 0
        Me.lblCostOfSoftware.Text = "Cost of software licensing:"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(140, 367)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(101, 28)
        Me.btnCalculate.TabIndex = 3
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(336, 367)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(101, 28)
        Me.btnClear.TabIndex = 4
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(526, 367)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(101, 28)
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'formSoftwareSales
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(786, 421)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.gbTotalCosts)
        Me.Controls.Add(Me.gbOptionalFeatures)
        Me.Controls.Add(Me.gbLicensingOptions)
        Me.Name = "formSoftwareSales"
        Me.Text = "Software Sales"
        Me.gbLicensingOptions.ResumeLayout(False)
        Me.gbLicensingOptions.PerformLayout()
        Me.gbOptionalFeatures.ResumeLayout(False)
        Me.gbOptionalFeatures.PerformLayout()
        Me.gbTotalCosts.ResumeLayout(False)
        Me.gbTotalCosts.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents gbLicensingOptions As GroupBox
    Friend WithEvents rbOneTimePurchase As RadioButton
    Friend WithEvents rbYearlyLicense As RadioButton
    Friend WithEvents gbOptionalFeatures As GroupBox
    Friend WithEvents cbCloudBackup As CheckBox
    Friend WithEvents cbTraining As CheckBox
    Friend WithEvents cbTechnicalSupport As CheckBox
    Friend WithEvents gbTotalCosts As GroupBox
    Friend WithEvents lblDisplayFeaturesCost As Label
    Friend WithEvents lblDisplaySoftwareCost As Label
    Friend WithEvents lblCostOfFeatures As Label
    Friend WithEvents lblCostOfSoftware As Label
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnClose As Button
End Class
