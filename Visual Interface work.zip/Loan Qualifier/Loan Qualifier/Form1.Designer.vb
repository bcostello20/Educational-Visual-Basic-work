﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formLoanQualifier
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblAnnualSalary = New System.Windows.Forms.Label()
        Me.lblYearsAtCurrentJob = New System.Windows.Forms.Label()
        Me.txtSalary = New System.Windows.Forms.TextBox()
        Me.txtYearsOnJob = New System.Windows.Forms.TextBox()
        Me.gbGetInformation = New System.Windows.Forms.GroupBox()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.btnCheckQualifications = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.gbGetInformation.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblAnnualSalary
        '
        Me.lblAnnualSalary.AutoSize = True
        Me.lblAnnualSalary.Location = New System.Drawing.Point(76, 34)
        Me.lblAnnualSalary.Name = "lblAnnualSalary"
        Me.lblAnnualSalary.Size = New System.Drawing.Size(92, 16)
        Me.lblAnnualSalary.TabIndex = 1
        Me.lblAnnualSalary.Text = "Annual salary:"
        '
        'lblYearsAtCurrentJob
        '
        Me.lblYearsAtCurrentJob.Location = New System.Drawing.Point(30, 71)
        Me.lblYearsAtCurrentJob.Name = "lblYearsAtCurrentJob"
        Me.lblYearsAtCurrentJob.Size = New System.Drawing.Size(138, 32)
        Me.lblYearsAtCurrentJob.TabIndex = 2
        Me.lblYearsAtCurrentJob.Text = "Number of years at          your current job:"
        '
        'txtSalary
        '
        Me.txtSalary.Location = New System.Drawing.Point(174, 31)
        Me.txtSalary.Name = "txtSalary"
        Me.txtSalary.Size = New System.Drawing.Size(100, 22)
        Me.txtSalary.TabIndex = 3
        '
        'txtYearsOnJob
        '
        Me.txtYearsOnJob.Location = New System.Drawing.Point(174, 81)
        Me.txtYearsOnJob.Name = "txtYearsOnJob"
        Me.txtYearsOnJob.Size = New System.Drawing.Size(100, 22)
        Me.txtYearsOnJob.TabIndex = 4
        '
        'gbGetInformation
        '
        Me.gbGetInformation.Controls.Add(Me.lblYearsAtCurrentJob)
        Me.gbGetInformation.Controls.Add(Me.txtYearsOnJob)
        Me.gbGetInformation.Controls.Add(Me.lblAnnualSalary)
        Me.gbGetInformation.Controls.Add(Me.txtSalary)
        Me.gbGetInformation.Location = New System.Drawing.Point(29, 34)
        Me.gbGetInformation.Name = "gbGetInformation"
        Me.gbGetInformation.Size = New System.Drawing.Size(375, 129)
        Me.gbGetInformation.TabIndex = 5
        Me.gbGetInformation.TabStop = False
        Me.gbGetInformation.Text = "Enter the following information:"
        '
        'lblMessage
        '
        Me.lblMessage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblMessage.Location = New System.Drawing.Point(29, 192)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(375, 23)
        Me.lblMessage.TabIndex = 6
        Me.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnCheckQualifications
        '
        Me.btnCheckQualifications.Location = New System.Drawing.Point(29, 229)
        Me.btnCheckQualifications.Name = "btnCheckQualifications"
        Me.btnCheckQualifications.Size = New System.Drawing.Size(121, 42)
        Me.btnCheckQualifications.TabIndex = 7
        Me.btnCheckQualifications.Text = "Check Qualifications"
        Me.btnCheckQualifications.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(173, 228)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(104, 43)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(300, 228)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(104, 43)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'formLoanQualifier
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(437, 287)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCheckQualifications)
        Me.Controls.Add(Me.lblMessage)
        Me.Controls.Add(Me.gbGetInformation)
        Me.Name = "formLoanQualifier"
        Me.Text = "Loan Qualifier"
        Me.gbGetInformation.ResumeLayout(False)
        Me.gbGetInformation.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblAnnualSalary As Label
    Friend WithEvents lblYearsAtCurrentJob As Label
    Friend WithEvents txtSalary As TextBox
    Friend WithEvents txtYearsOnJob As TextBox
    Friend WithEvents gbGetInformation As GroupBox
    Friend WithEvents lblMessage As Label
    Friend WithEvents btnCheckQualifications As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
