﻿Public Class formLoanQualifier
    Private Sub btnCheckQualifications_Click(sender As Object, e As EventArgs) Handles btnCheckQualifications.Click
        ' Member variables
        Dim dblSalary As Double ' The annual salary
        Dim intYearsOnJob As Integer ' The number of years at current job

        Try
            ' Get the information from the user
            dblSalary = CDbl(txtSalary.Text)
            intYearsOnJob = CInt(txtYearsOnJob.Text)

            ' Check to see if the user qualifies for a loan
            If dblSalary > 30000 Then
                If intYearsOnJob > 2 Then
                    lblMessage.Text = "The applicant qualifies for the loan."
                Else
                    lblMessage.Text = "The applicant does not qualify for the loan."
                End If
            Else
                If intYearsOnJob > 5 Then
                    lblMessage.Text = "The applicant qualifies for the loan."
                Else
                    lblMessage.Text = "The applicant does not qualify for the loan."
                End If
            End If

        Catch ex As Exception
            ' Error message to display if values entered by user are not numeric
            lblMessage.Text = "Please enter numeric values only."
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clear the text boxes
        txtSalary.Clear()
        txtYearsOnJob.Clear()

        ' Empty the label
        lblMessage.Text = String.Empty
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
