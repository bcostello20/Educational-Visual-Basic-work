﻿Public Class frmLoanCalculator
    ' Class-level variables
    Const dblMONTHS_YEAR As Double = 12 ' Months per year
    Const dblNEW_RATE As Double = 0.05 ' Interest rate for new cars
    Const dblUSED_RATE As Double = 0.08 ' Interest rate for used cars

    ' Class-level variable to store the annual interest rate
    Dim dblAnnualRate As Double = dblNEW_RATE

    Private Sub BtnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim dblVehicleCost As Double ' The vehicle cost
        Dim dblDownPayment As Double ' The down payment
        Dim intMonths As Integer ' The number of months for the loan
        Dim dblLoan As Double ' The amount of the loan
        Dim dblMonthlyPayment As Double ' The monthly payment
        Dim dblInterest As Double ' The interest paid for the period
        Dim dblPrincipal As Double ' The principal paid for the period
        Dim intCount As Integer ' The counter for the loop
        Dim strOut As String ' Used to hold a line of output
        Dim blnInputOk As Boolean = True

        ' Get the vehicle cost, while validating
        If Not Double.TryParse(txtCost.Text, dblVehicleCost) Then
            lblMessage.Text = "Vehicle cost must be a number"
            blnInputOk = False
        End If

        ' Get the down payment, while validating
        If Not Double.TryParse(txtDownPayment.Text, dblDownPayment) Then
            lblMessage.Text = "Down payment must be a number"
            blnInputOk = False
        End If

        ' Get the number of months, while validating
        If Not Integer.TryParse(txtMonths.Text, intMonths) Then
            lblMessage.Text = "Months must be an integer"
            blnInputOk = False
        End If

        If blnInputOk = True Then
            ' Calculate the loan amount and monthly payment
            dblLoan = dblVehicleCost - dblDownPayment
            dblMonthlyPayment = Pmt(dblAnnualRate / dblMONTHS_YEAR, intMonths, -dblLoan)

            ' Clear the list box and message label
            lstOutput.Items.Clear()
            lblMessage.Text = String.Empty

            For intCount = 1 To intMonths
                ' Calculate the interest for the current period
                dblInterest = IPmt(dblAnnualRate / dblMONTHS_YEAR, intCount, intMonths, -dblLoan)

                ' Calculate the principal for the current period
                dblPrincipal = PPmt(dblAnnualRate / dblMONTHS_YEAR, intCount, intMonths, -dblLoan)

                ' Start building the output string with the month
                strOut = "Month " & intCount.ToString("d2")

                ' Add the payment amount to the output string
                strOut &= ": payment = " & dblMonthlyPayment.ToString("n2")

                ' Add the interest amount to the output string
                strOut &= ", interest = " & dblInterest.ToString("n2")

                ' Add the principal for the period
                strOut &= ", principal = " & dblPrincipal.ToString("n2")
                ' Add the output string to the list box
                lstOutput.Items.Add(strOut)
            Next
        End If
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Reset the interest rate
        dblAnnualRate = dblNEW_RATE

        ' Clear the text boxes
        txtCost.Clear()
        txtDownPayment.Clear()
        txtMonths.Clear()

        ' Clear the list box
        lstOutput.Items.Clear()

        ' Set the default interest rate for new car loans
        lblAnnualRate.Text = dblNEW_RATE.ToString("p")
        radNew.Checked = True

        ' Clear any error messages
        lblMessage.Text = String.Empty

        ' Reset the focus to txtCost
        txtCost.Focus()
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' End the progam
        Me.Close()
    End Sub

    Private Sub RadNew_CheckedChanged(sender As Object, e As EventArgs) Handles radNew.CheckedChanged
        ' If the New radio button is checked, then the user has selected a new car loan
        If radNew.Checked = True Then
            dblAnnualRate = dblNEW_RATE
            lblAnnualRate.Text = dblNEW_RATE.ToString("p")
            lstOutput.Items.Clear()
        End If
    End Sub

    Private Sub RadUsed_CheckedChanged(sender As Object, e As EventArgs) Handles radUsed.CheckedChanged
        ' If the Used radio button if checked, the the user has selected a used car loan
        If radUsed.Checked = True Then
            dblAnnualRate = dblUSED_RATE
            lblAnnualRate.Text = dblUSED_RATE.ToString("p")
            lstOutput.Items.Clear()
        End If
    End Sub
End Class
