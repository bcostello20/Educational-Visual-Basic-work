﻿Imports System.IO

Public Class Form1
    Const strFILENAME As String = "MovieList.txt"

    'Structure of the Movie starts here
    Structure Movie
        Dim strMovieName As String
        Dim intYearProduced As Integer
        Dim intTime As Integer
        Dim dblRating As Double
    End Structure


    Private Sub SaveToFileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveToFileToolStripMenuItem.Click
        'Make an instance of Movie class
        Dim movie As New Movie

        With movie
            .strMovieName = txtVideoName.Text
            .intYearProduced = CInt(txtYearProduced.Text)
            .intTime = CInt(txtRunningTime.Text)
            .dblRating = CDbl(txtRating.Text)
        End With
        'Call the sub procedure with the instance of Movie, pass by reference
        WriteRecordToFile(movie)

    End Sub
    Sub WriteRecordToFile(ByRef movie As Movie)

        ' Save the record to the file.
        Dim videoFile As StreamWriter

        If File.Exists(strFILENAME) Then
            ' Open the file.
            videoFile = File.AppendText(strFILENAME)
        Else
            ' The file does not exist, so create it.
            videoFile = File.CreateText(strFILENAME)
        End If

        ' Write the record.
        videoFile.WriteLine(movie.strMovieName)
        videoFile.WriteLine(movie.intYearProduced.ToString())
        videoFile.WriteLine(movie.intTime.ToString())
        videoFile.WriteLine(movie.dblRating.ToString())

        ' Close the file.
        videoFile.Close()

        ' Clear the form.
        ClearForm()
    End Sub
    Sub ClearForm()
        ' Clear the form.
        txtVideoName.Clear()
        txtYearProduced.Clear()
        txtRunningTime.Clear()
        txtRating.Clear()

        ' Reset the focus.
        txtVideoName.Focus()
    End Sub
    Private Sub ByVideoNameToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ByVideoNameToolStripMenuItem.Click
        Dim strMovieName = txtVideoName.Text
        FindRecord(strMovieName)
    End Sub
    Sub FindRecord(ByVal strName As String)

        ' Search for a record in the file.
        Dim video As New Movie
        Dim blnFound As Boolean = False
        Dim videoFile As StreamReader

        If File.Exists(strFILENAME) Then
            ' Open the file.
            videoFile = File.OpenText(strFILENAME)

            ' Search the records.
            Do Until (videoFile.Peek = -1) Or blnFound

                ' Read the next record.
                video.strMovieName = videoFile.ReadLine
                video.intYearProduced = CInt(videoFile.ReadLine)
                video.intTime = CInt(videoFile.ReadLine)
                video.dblRating = CInt(videoFile.ReadLine)

                ' Is it the one?
                If strName.ToUpper = video.strMovieName.ToUpper Then
                    blnFound = True
                End If
            Loop

            ' Close the file.
            videoFile.Close()

            If blnFound Then

                ' The name was found.
                txtVideoName.Text = video.strMovieName
                txtYearProduced.Text = video.intYearProduced.ToString()
                txtRunningTime.Text = video.intTime.ToString()
                txtRating.Text = video.dblRating.ToString()
            Else
                ' The name was not found
                MessageBox.Show(strName & " was not found.", "Record Not Found")
            End If
        Else
            ' Error opening file.
            MessageBox.Show("Cannot open file.", "Error")
        End If

    End Sub

End Class
