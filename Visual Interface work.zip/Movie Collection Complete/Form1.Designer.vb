﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ByVideoNameToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.grbVideoData = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblVideo = New System.Windows.Forms.Label()
        Me.txtRating = New System.Windows.Forms.TextBox()
        Me.txtRunningTime = New System.Windows.Forms.TextBox()
        Me.txtYearProduced = New System.Windows.Forms.TextBox()
        Me.txtVideoName = New System.Windows.Forms.TextBox()
        Me.MenuStrip1.SuspendLayout()
        Me.grbVideoData.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.SearchToolStripMenuItem, Me.ReportToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveToFileToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'SaveToFileToolStripMenuItem
        '
        Me.SaveToFileToolStripMenuItem.Name = "SaveToFileToolStripMenuItem"
        Me.SaveToFileToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.SaveToFileToolStripMenuItem.Text = "Save to File"
        '
        'SearchToolStripMenuItem
        '
        Me.SearchToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ByVideoNameToolStripMenuItem})
        Me.SearchToolStripMenuItem.Name = "SearchToolStripMenuItem"
        Me.SearchToolStripMenuItem.Size = New System.Drawing.Size(54, 20)
        Me.SearchToolStripMenuItem.Text = "Search"
        '
        'ByVideoNameToolStripMenuItem
        '
        Me.ByVideoNameToolStripMenuItem.Name = "ByVideoNameToolStripMenuItem"
        Me.ByVideoNameToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ByVideoNameToolStripMenuItem.Text = "By Video Name"
        '
        'ReportToolStripMenuItem
        '
        Me.ReportToolStripMenuItem.Name = "ReportToolStripMenuItem"
        Me.ReportToolStripMenuItem.Size = New System.Drawing.Size(54, 20)
        Me.ReportToolStripMenuItem.Text = "Report"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'grbVideoData
        '
        Me.grbVideoData.Controls.Add(Me.Label3)
        Me.grbVideoData.Controls.Add(Me.Label2)
        Me.grbVideoData.Controls.Add(Me.Label1)
        Me.grbVideoData.Controls.Add(Me.lblVideo)
        Me.grbVideoData.Controls.Add(Me.txtRating)
        Me.grbVideoData.Controls.Add(Me.txtRunningTime)
        Me.grbVideoData.Controls.Add(Me.txtYearProduced)
        Me.grbVideoData.Controls.Add(Me.txtVideoName)
        Me.grbVideoData.Location = New System.Drawing.Point(70, 99)
        Me.grbVideoData.Name = "grbVideoData"
        Me.grbVideoData.Size = New System.Drawing.Size(592, 302)
        Me.grbVideoData.TabIndex = 1
        Me.grbVideoData.TabStop = False
        Me.grbVideoData.Text = "View Data"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(96, 174)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Rating:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(61, 134)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Running Time:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(61, 100)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Year Produced:"
        '
        'lblVideo
        '
        Me.lblVideo.AutoSize = True
        Me.lblVideo.Location = New System.Drawing.Point(72, 68)
        Me.lblVideo.Name = "lblVideo"
        Me.lblVideo.Size = New System.Drawing.Size(68, 13)
        Me.lblVideo.TabIndex = 5
        Me.lblVideo.Text = "Video Name:"
        '
        'txtRating
        '
        Me.txtRating.Location = New System.Drawing.Point(197, 171)
        Me.txtRating.Name = "txtRating"
        Me.txtRating.Size = New System.Drawing.Size(210, 20)
        Me.txtRating.TabIndex = 4
        '
        'txtRunningTime
        '
        Me.txtRunningTime.Location = New System.Drawing.Point(198, 131)
        Me.txtRunningTime.Name = "txtRunningTime"
        Me.txtRunningTime.Size = New System.Drawing.Size(210, 20)
        Me.txtRunningTime.TabIndex = 2
        '
        'txtYearProduced
        '
        Me.txtYearProduced.Location = New System.Drawing.Point(197, 98)
        Me.txtYearProduced.Name = "txtYearProduced"
        Me.txtYearProduced.Size = New System.Drawing.Size(211, 20)
        Me.txtYearProduced.TabIndex = 1
        '
        'txtVideoName
        '
        Me.txtVideoName.Location = New System.Drawing.Point(197, 61)
        Me.txtVideoName.Name = "txtVideoName"
        Me.txtVideoName.Size = New System.Drawing.Size(212, 20)
        Me.txtVideoName.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.grbVideoData)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Movie Collection"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.grbVideoData.ResumeLayout(False)
        Me.grbVideoData.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SearchToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReportToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents grbVideoData As GroupBox
    Friend WithEvents lblVideo As Label
    Friend WithEvents txtRating As TextBox
    Friend WithEvents txtRunningTime As TextBox
    Friend WithEvents txtYearProduced As TextBox
    Friend WithEvents txtVideoName As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents SaveToFileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ByVideoNameToolStripMenuItem As ToolStripMenuItem
End Class
