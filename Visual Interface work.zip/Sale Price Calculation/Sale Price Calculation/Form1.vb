﻿Public Class frmSalePriceCalculator
    Private decRetail As Decimal ' Stores the retail price
    Private decPercetage As Decimal ' Stores the discount percentage

    Private Function ValidateInputFields() As Boolean
        ' Convert the input fields
        ' Return false if any field is not numeric and displays a message

        If Not Decimal.TryParse(txtRetailPrice.Text, decRetail) Then
            lblMessage.Text = "Retail price must be numeric"
            Return False
        End If

        If Not Decimal.TryParse(txtDiscountPercent.Text, decPercetage) Then
            lblMessage.Text = "Discount percentage must be numeric"
            Return False
        End If

        Return True
    End Function

    Function CalculateSalePrice(ByVal decRetail As Decimal, ByVal decPercentage As Decimal) As Decimal
        ' Calculate and return the sale price
        Dim decSalePrice As Decimal

        decSalePrice = decRetail - (decRetail * decPercentage)
        Return decSalePrice
    End Function

    Private Sub BtnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim decSalePrice As Decimal

        ' Clear any prior messages
        lblMessage.Text = String.Empty

        ' If the user input is valid, display the sale price
        If ValidateInputFields() Then
            decSalePrice = CalculateSalePrice(decRetail, decPercetage)
            lblSalePrice.Text = decSalePrice.ToString("c")
        End If
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' End the program
        Me.Close()
    End Sub

End Class
