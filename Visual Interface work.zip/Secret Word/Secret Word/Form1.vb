﻿Public Class formSecretWord
    Private Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        ' Compare the user input with the secret word
        If txtSecretWord.Text.ToLower() = "prospero" Then
            lblMessage.Text = "Congrats! That is the secret word!"
        Else
            lblMessage.Text = "Incorrect! That is NOT the secret word!"
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
