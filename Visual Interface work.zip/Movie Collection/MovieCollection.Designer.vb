﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMovieCollection
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.grbVideoData = New System.Windows.Forms.GroupBox()
        Me.txtRating = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtRunningTime = New System.Windows.Forms.TextBox()
        Me.txtYearProduced = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtVideoName = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.mnuMenuStrip = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileSave = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSearch = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSearchName = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuReport = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.sfdSaveFile = New System.Windows.Forms.SaveFileDialog()
        Me.txtOutput = New System.Windows.Forms.TextBox()
        Me.grbVideoData.SuspendLayout()
        Me.mnuMenuStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'grbVideoData
        '
        Me.grbVideoData.Controls.Add(Me.txtRating)
        Me.grbVideoData.Controls.Add(Me.Label4)
        Me.grbVideoData.Controls.Add(Me.txtRunningTime)
        Me.grbVideoData.Controls.Add(Me.txtYearProduced)
        Me.grbVideoData.Controls.Add(Me.Label3)
        Me.grbVideoData.Controls.Add(Me.Label2)
        Me.grbVideoData.Controls.Add(Me.txtVideoName)
        Me.grbVideoData.Controls.Add(Me.Label1)
        Me.grbVideoData.Location = New System.Drawing.Point(12, 42)
        Me.grbVideoData.Name = "grbVideoData"
        Me.grbVideoData.Size = New System.Drawing.Size(304, 159)
        Me.grbVideoData.TabIndex = 0
        Me.grbVideoData.TabStop = False
        Me.grbVideoData.Text = "Video Data"
        '
        'txtRating
        '
        Me.txtRating.Location = New System.Drawing.Point(111, 121)
        Me.txtRating.Name = "txtRating"
        Me.txtRating.Size = New System.Drawing.Size(55, 20)
        Me.txtRating.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(63, 121)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Rating:"
        '
        'txtRunningTime
        '
        Me.txtRunningTime.Location = New System.Drawing.Point(111, 93)
        Me.txtRunningTime.Name = "txtRunningTime"
        Me.txtRunningTime.Size = New System.Drawing.Size(100, 20)
        Me.txtRunningTime.TabIndex = 3
        '
        'txtYearProduced
        '
        Me.txtYearProduced.Location = New System.Drawing.Point(111, 66)
        Me.txtYearProduced.Name = "txtYearProduced"
        Me.txtYearProduced.Size = New System.Drawing.Size(100, 20)
        Me.txtYearProduced.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(28, 93)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Running Time:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(24, 66)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(81, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Year Produced:"
        '
        'txtVideoName
        '
        Me.txtVideoName.Location = New System.Drawing.Point(111, 40)
        Me.txtVideoName.Name = "txtVideoName"
        Me.txtVideoName.Size = New System.Drawing.Size(180, 20)
        Me.txtVideoName.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(36, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Video Name:"
        '
        'mnuMenuStrip
        '
        Me.mnuMenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuSearch, Me.mnuReport, Me.mnuHelp})
        Me.mnuMenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.mnuMenuStrip.Name = "mnuMenuStrip"
        Me.mnuMenuStrip.Size = New System.Drawing.Size(622, 24)
        Me.mnuMenuStrip.TabIndex = 1
        Me.mnuMenuStrip.Text = "MenuStrip1"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileSave, Me.mnuFileExit})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(37, 20)
        Me.mnuFile.Text = "File"
        '
        'mnuFileSave
        '
        Me.mnuFileSave.Name = "mnuFileSave"
        Me.mnuFileSave.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.mnuFileSave.Size = New System.Drawing.Size(138, 22)
        Me.mnuFileSave.Text = "Save"
        '
        'mnuFileExit
        '
        Me.mnuFileExit.Name = "mnuFileExit"
        Me.mnuFileExit.Size = New System.Drawing.Size(180, 22)
        Me.mnuFileExit.Text = "Exit"
        '
        'mnuSearch
        '
        Me.mnuSearch.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuSearchName})
        Me.mnuSearch.Name = "mnuSearch"
        Me.mnuSearch.Size = New System.Drawing.Size(54, 20)
        Me.mnuSearch.Text = "Search"
        '
        'mnuSearchName
        '
        Me.mnuSearchName.Name = "mnuSearchName"
        Me.mnuSearchName.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
        Me.mnuSearchName.Size = New System.Drawing.Size(180, 22)
        Me.mnuSearchName.Text = "By Name"
        '
        'mnuReport
        '
        Me.mnuReport.Name = "mnuReport"
        Me.mnuReport.Size = New System.Drawing.Size(54, 20)
        Me.mnuReport.Text = "Report"
        '
        'mnuHelp
        '
        Me.mnuHelp.Name = "mnuHelp"
        Me.mnuHelp.Size = New System.Drawing.Size(44, 20)
        Me.mnuHelp.Text = "Help"
        '
        'txtOutput
        '
        Me.txtOutput.Location = New System.Drawing.Point(334, 42)
        Me.txtOutput.Multiline = True
        Me.txtOutput.Name = "txtOutput"
        Me.txtOutput.ReadOnly = True
        Me.txtOutput.Size = New System.Drawing.Size(272, 157)
        Me.txtOutput.TabIndex = 2
        '
        'frmMovieCollection
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(622, 211)
        Me.Controls.Add(Me.txtOutput)
        Me.Controls.Add(Me.grbVideoData)
        Me.Controls.Add(Me.mnuMenuStrip)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MainMenuStrip = Me.mnuMenuStrip
        Me.MaximizeBox = False
        Me.Name = "frmMovieCollection"
        Me.Text = "Movie Collection"
        Me.grbVideoData.ResumeLayout(False)
        Me.grbVideoData.PerformLayout()
        Me.mnuMenuStrip.ResumeLayout(False)
        Me.mnuMenuStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grbVideoData As GroupBox
    Friend WithEvents txtRating As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtRunningTime As TextBox
    Friend WithEvents txtYearProduced As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtVideoName As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents mnuMenuStrip As MenuStrip
    Friend WithEvents mnuFile As ToolStripMenuItem
    Friend WithEvents mnuSearch As ToolStripMenuItem
    Friend WithEvents mnuReport As ToolStripMenuItem
    Friend WithEvents mnuHelp As ToolStripMenuItem
    Friend WithEvents mnuFileSave As ToolStripMenuItem
    Friend WithEvents mnuFileExit As ToolStripMenuItem
    Friend WithEvents sfdSaveFile As SaveFileDialog
    Friend WithEvents mnuSearchName As ToolStripMenuItem
    Friend WithEvents txtOutput As TextBox
End Class
