﻿Imports System.IO

Public Class frmMovieCollection

    ' Member variables
    Dim reader As StreamReader ' Instance of the StreamReader object
    Dim writer As StreamWriter ' Instance of the StreamWriter object
    Dim strFileName As String ' The name of the file
    Dim movieName As String ' Movie name for searching

    Public Structure MovieCollection
        Public strMovieName As String
        Public strYearProduced As Integer
        Public strRunningTime As String
        Public strRating As Double
    End Structure

    Private Sub FrmMovieCollection_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Get a file name from the user
        strFileName = InputBox("Enter name of file.")

        ' Check if the file exists, it not create a new file
        If System.IO.File.Exists(strFileName) Then
            ' Do nothing here
        Else
            ' Create the new text file
            writer = File.CreateText(strFileName)
        End If
    End Sub

    Private Sub MnuFileSave_Click(sender As Object, e As EventArgs) Handles mnuFileSave.Click
        writer = File.AppendText(strFileName)
        writer.WriteLine(txtVideoName.Text)
        writer.WriteLine(txtYearProduced.Text)
        writer.WriteLine(txtRunningTime.Text)
        writer.WriteLine(txtRating.Text)
        writer.Close()
    End Sub

    Private Sub MnuSearchName_Click(sender As Object, e As EventArgs) Handles mnuSearchName.Click

        reader = My.Computer.FileSystem.OpenTextFileReader(strFileName)

        Dim mC As MovieCollection = New MovieCollection()

        movieName = InputBox("Enter name of movie.")

        Dim findName = IO.File.ReadLines(strFileName)

        If findName.Contains(movieName) Then
            mC.strMovieName = reader.ReadLine()
            mC.strYearProduced = CInt(reader.ReadLine())
            mC.strRunningTime = reader.ReadLine()
            mC.strRating = CDbl(reader.ReadLine())
            txtOutput.Text = mC.strMovieName & vbNewLine & mC.strYearProduced & vbNewLine & mC.strRunningTime & vbNewLine & mC.strRating
        End If

    End Sub

    Private Sub MnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        ' End the program
        Me.Close()
    End Sub
End Class
