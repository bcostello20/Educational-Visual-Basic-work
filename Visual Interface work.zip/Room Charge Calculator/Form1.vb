﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Get the current date and display it
        lblDateToday.Text = Now.ToString("D")
        ' Get the curret time and display it
        lblTimeToday.Text = Now.ToString("T")
    End Sub

    Private Sub BtnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        ' Variable declarations for the calculations
        Dim decRoomCharges As Decimal ' Room charges total
        Dim decAddCharges As Decimal ' Additional Charges
        Dim decSubTotal As Decimal ' Subtotal
        Dim decTax As Decimal ' Tax
        Dim decTotal As Decimal ' Total of all charges
        Const decTAX_RATE As Decimal = 0.08D ' Tax rate

        ' Input validations to check for numeric values in Room Information fields
        If IsNumeric(txtNights.Text) = False Then
            MessageBox.Show("Nights value must be numeric, please re-enter a value.")
            txtNights.Text = String.Empty
        ElseIf IsNumeric(txtNightlyCharge.Text) = False Then
            MessageBox.Show("Nightly charges value must be numeric, please re-enter a value.")
            txtNightlyCharge.Text = String.Empty
        Else
            ' Calculate and display the room charges
            decRoomCharges = CDec(txtNights.Text) * CDec(txtNightlyCharge.Text)
            lblRoomCharges.Text = decRoomCharges.ToString("c")
        End If

        ' Input validations to check for numeric values in Additional Charges fields
        If IsNumeric(txtRoomService.Text) = False Then
            MessageBox.Show("Room service value must be numeric, please re-enter a value.")
            txtRoomService.Text = String.Empty
        ElseIf IsNumeric(txtTelephone.Text) = False Then
            MessageBox.Show("Telephone charges value must be numeric, please re-enter a value.")
            txtTelephone.Text = String.Empty
        ElseIf IsNumeric(txtMisc.Text) = False Then
            MessageBox.Show("Misc. charges value must be numeric, please re-enter a value.")
            txtMisc.Text = String.Empty
        Else
            ' Calculate and display the additional charges
            decAddCharges = CDec(txtRoomService.Text) + CDec(txtTelephone.Text) + CDec(txtMisc.Text)
            lblAddCharges.Text = decAddCharges.ToString("c")
        End If

        ' Calculate and display the subtotal
        decSubTotal = decRoomCharges + decAddCharges
            lblSubTotal.Text = decSubTotal.ToString("c")

            ' Calculate and display the tax
            decTax = decSubTotal * decTAX_RATE
            lblTax.Text = decTax.ToString("c")

            ' Calculate and display the total charges
            decTotal = decSubTotal + decTax
            lblTotal.Text = decTotal.ToString("c")

            ' Catch ex As Exception
        ' Error message
        ' MessageBox.Show("All input must be valid numeric values.")
        ' End Try

    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clear the room info fields
        txtNights.Clear()
        txtNightlyCharge.Clear()

        ' Clear the additional charges fields
        txtRoomService.Clear()
        txtTelephone.Clear()
        txtMisc.Clear()

        ' Clear the decTotal fields
        lblRoomCharges.Text = String.Empty
        lblAddCharges.Text = String.Empty
        lblSubTotal.Text = String.Empty
        lblTax.Text = String.Empty
        lblTotal.Text = String.Empty

        ' Get the current date and display it
        lblDateToday.Text = Now.ToString("D")

        ' Get the current time and display it
        lblTimeToday.Text = Now.ToString("T")

        ' Reset the focus to the first field
        txtNights.Focus()
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
