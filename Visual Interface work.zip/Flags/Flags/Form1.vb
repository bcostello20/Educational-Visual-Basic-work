﻿Public Class Form1
    Private Sub picFinland_Click(sender As Object, e As EventArgs) Handles picFinland.Click
        lblCountry.Text = "Finland"
    End Sub

    Private Sub picFrance_Click(sender As Object, e As EventArgs) Handles picFrance.Click
        lblCountry.Text = "France"
    End Sub

    Private Sub picGermany_Click(sender As Object, e As EventArgs) Handles picGermany.Click
        lblCountry.Text = "Germany"
    End Sub
End Class
