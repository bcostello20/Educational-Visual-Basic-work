﻿Public Class Form1
    Private Sub BtnShowAnswer_Click(sender As Object, e As EventArgs) Handles btnShowAnswer.Click
        'Change question mark to the answer
        lblAnswer.Text = "82"
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Ends the program
        Me.Close()
    End Sub

End Class
