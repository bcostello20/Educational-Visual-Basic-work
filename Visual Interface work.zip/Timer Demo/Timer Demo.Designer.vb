﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblTimer = New System.Windows.Forms.Label()
        Me.tmrTimer = New System.Windows.Forms.Timer(Me.components)
        Me.btnToggleTimer = New System.Windows.Forms.Button()
        Me.picTwo = New System.Windows.Forms.PictureBox()
        Me.picOne = New System.Windows.Forms.PictureBox()
        Me.btnExit = New System.Windows.Forms.Button()
        CType(Me.picTwo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picOne, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblTimer
        '
        Me.lblTimer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTimer.Location = New System.Drawing.Point(26, 43)
        Me.lblTimer.Name = "lblTimer"
        Me.lblTimer.Size = New System.Drawing.Size(75, 23)
        Me.lblTimer.TabIndex = 1
        Me.lblTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tmrTimer
        '
        Me.tmrTimer.Interval = 125
        '
        'btnToggleTimer
        '
        Me.btnToggleTimer.Location = New System.Drawing.Point(26, 104)
        Me.btnToggleTimer.Name = "btnToggleTimer"
        Me.btnToggleTimer.Size = New System.Drawing.Size(75, 52)
        Me.btnToggleTimer.TabIndex = 2
        Me.btnToggleTimer.Text = "Start Timer"
        Me.btnToggleTimer.UseVisualStyleBackColor = True
        '
        'picTwo
        '
        Me.picTwo.Image = Global.Timer_Demo.My.Resources.Resources.Two
        Me.picTwo.Location = New System.Drawing.Point(162, 12)
        Me.picTwo.Name = "picTwo"
        Me.picTwo.Size = New System.Drawing.Size(288, 236)
        Me.picTwo.TabIndex = 3
        Me.picTwo.TabStop = False
        '
        'picOne
        '
        Me.picOne.Image = Global.Timer_Demo.My.Resources.Resources.One
        Me.picOne.Location = New System.Drawing.Point(162, 12)
        Me.picOne.Name = "picOne"
        Me.picOne.Size = New System.Drawing.Size(288, 236)
        Me.picOne.TabIndex = 0
        Me.picOne.TabStop = False
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(26, 162)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 52)
        Me.btnExit.TabIndex = 4
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(474, 309)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.picTwo)
        Me.Controls.Add(Me.btnToggleTimer)
        Me.Controls.Add(Me.lblTimer)
        Me.Controls.Add(Me.picOne)
        Me.Name = "Form1"
        Me.Text = "Timer Demo"
        CType(Me.picTwo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picOne, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents picOne As PictureBox
    Friend WithEvents lblTimer As Label
    Friend WithEvents tmrTimer As Timer
    Friend WithEvents btnToggleTimer As Button
    Friend WithEvents picTwo As PictureBox
    Friend WithEvents btnExit As Button
End Class
