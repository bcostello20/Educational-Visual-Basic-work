﻿Public Class Form1

    Private intSeconds As Integer ' Counter to increase seconds by 1

    Private Sub BtnToggleTimer_Click(sender As Object, e As EventArgs) Handles btnToggleTimer.Click
        ' If the timer is enabled make it disabled and change button text to "Start Timer"
        If tmrTimer.Enabled = True Then
            tmrTimer.Enabled = False
            btnToggleTimer.Text = "&Start Timer"
            ' Otherwise enable the timer and set button text to "Stop Timer"
        Else
            tmrTimer.Enabled = True
            btnToggleTimer.Text = "&Stop Timer"
        End If
    End Sub

    Private Sub TmrTimer_Tick(sender As Object, e As EventArgs) Handles tmrTimer.Tick
        intSeconds += 1 ' Increase seconds by 1
        lblTimer.Text = intSeconds.ToString() ' Display the seconds in the label

        ' If the first picture is visible, make it invisible and make the second picture visible
        If picOne.Visible = True Then
            picOne.Visible = False
            picTwo.Visible = True
            ' Otherwise make first picture visible and second picture invisible
        Else
            picOne.Visible = True
            picTwo.Visible = False
        End If
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' End the program
        Me.Close()
    End Sub
End Class
