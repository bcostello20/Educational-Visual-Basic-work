﻿Imports System.IO

Public Class Form1

    Dim theFile As StreamReader ' Instance of the StreamWriter object
    Dim strFileName As String ' To hold the file name
    Dim intRecordNumber As Integer = 1 ' The record number counter

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Get a file name from the user
        strFileName = InputBox("Enter name of file.")
        theFile = New StreamReader(strFileName)
        File.OpenText(strFileName) ' Open the file

        ' Set the record number label to 1 and read the lines for the labels
        lblRecordNumber.Text = intRecordNumber
        lblFirstName.Text = theFile.ReadLine
        lblMiddleName.Text = theFile.ReadLine
        lblLastName.Text = theFile.ReadLine
        lblEmployeeNumber.Text = theFile.ReadLine
        lblDepartment.Text = theFile.ReadLine
        lblTelephone.Text = theFile.ReadLine
        lblExtension.Text = theFile.ReadLine
        lblEmailAddress.Text = theFile.ReadLine
    End Sub

    Private Sub btnNextRecord_Click(sender As Object, e As EventArgs) Handles btnNextRecord.Click
        ' Increment record number by 1 each button click and read the lines for the labels
        Try
            intRecordNumber += 1
            lblRecordNumber.Text = intRecordNumber
            lblFirstName.Text = theFile.ReadLine
            lblMiddleName.Text = theFile.ReadLine
            lblLastName.Text = theFile.ReadLine
            lblEmployeeNumber.Text = theFile.ReadLine
            lblDepartment.Text = theFile.ReadLine
            lblTelephone.Text = theFile.ReadLine
            lblExtension.Text = theFile.ReadLine
            lblEmailAddress.Text = theFile.ReadLine

            ' Peek at next line to see if it is empty, if so, close the file and tell the user 
            If theFile.Peek() = -1 Then
                theFile.Close()
                intRecordNumber -= 1 ' To keep the record number at most recent amount
                MessageBox.Show("End of data reached.")
            End If
        Catch
            intRecordNumber -= 1 ' To keep the record number at most recent amount
            ' Error message telling the user the file has been closed
            MessageBox.Show("The file has been closed.")
        End Try

    End Sub

End Class
