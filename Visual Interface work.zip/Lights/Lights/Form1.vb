﻿Public Class Form1

    Private Sub BtnSwitchLight_Click(sender As Object, e As EventArgs) Handles btnSwitchLight.Click
        LightState() ' Call the LightState method to turn the light ON and OFF based on its current state
    End Sub

    Public Sub LightState()
        ' Turn the light ON or OFF based on its current state
        If picLightOn.Visible = True Then
            picLightOff.Visible = True ' Turn the light OFF
            picLightOn.Visible = False
            lblLightState.Text = "OFF" ' Make the label text say OFF
        Else
            picLightOn.Visible = True ' Turn the light ON
            picLightOff.Visible = False
            lblLightState.Text = "ON" ' Make the label text say ON
        End If
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' End the program
        Me.Close()
    End Sub
End Class
