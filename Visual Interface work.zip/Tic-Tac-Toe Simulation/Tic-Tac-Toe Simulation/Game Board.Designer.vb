﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTicTacToe
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblSpot1 = New System.Windows.Forms.Label()
        Me.lblSpot2 = New System.Windows.Forms.Label()
        Me.lblSpot3 = New System.Windows.Forms.Label()
        Me.lblSpot4 = New System.Windows.Forms.Label()
        Me.lblSpot5 = New System.Windows.Forms.Label()
        Me.lblSpot6 = New System.Windows.Forms.Label()
        Me.lblSpot7 = New System.Windows.Forms.Label()
        Me.lblSpot8 = New System.Windows.Forms.Label()
        Me.lblSpot9 = New System.Windows.Forms.Label()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.btnNewGame = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblSpot1
        '
        Me.lblSpot1.BackColor = System.Drawing.Color.White
        Me.lblSpot1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSpot1.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSpot1.Location = New System.Drawing.Point(35, 33)
        Me.lblSpot1.Name = "lblSpot1"
        Me.lblSpot1.Size = New System.Drawing.Size(116, 105)
        Me.lblSpot1.TabIndex = 0
        Me.lblSpot1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSpot2
        '
        Me.lblSpot2.BackColor = System.Drawing.Color.White
        Me.lblSpot2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSpot2.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSpot2.Location = New System.Drawing.Point(184, 33)
        Me.lblSpot2.Name = "lblSpot2"
        Me.lblSpot2.Size = New System.Drawing.Size(116, 105)
        Me.lblSpot2.TabIndex = 1
        Me.lblSpot2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSpot3
        '
        Me.lblSpot3.BackColor = System.Drawing.Color.White
        Me.lblSpot3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSpot3.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSpot3.Location = New System.Drawing.Point(332, 33)
        Me.lblSpot3.Name = "lblSpot3"
        Me.lblSpot3.Size = New System.Drawing.Size(116, 105)
        Me.lblSpot3.TabIndex = 2
        Me.lblSpot3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSpot4
        '
        Me.lblSpot4.BackColor = System.Drawing.Color.White
        Me.lblSpot4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSpot4.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSpot4.Location = New System.Drawing.Point(35, 160)
        Me.lblSpot4.Name = "lblSpot4"
        Me.lblSpot4.Size = New System.Drawing.Size(116, 105)
        Me.lblSpot4.TabIndex = 3
        Me.lblSpot4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSpot5
        '
        Me.lblSpot5.BackColor = System.Drawing.Color.White
        Me.lblSpot5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSpot5.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSpot5.Location = New System.Drawing.Point(184, 160)
        Me.lblSpot5.Name = "lblSpot5"
        Me.lblSpot5.Size = New System.Drawing.Size(116, 105)
        Me.lblSpot5.TabIndex = 4
        Me.lblSpot5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSpot6
        '
        Me.lblSpot6.BackColor = System.Drawing.Color.White
        Me.lblSpot6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSpot6.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSpot6.Location = New System.Drawing.Point(332, 160)
        Me.lblSpot6.Name = "lblSpot6"
        Me.lblSpot6.Size = New System.Drawing.Size(116, 105)
        Me.lblSpot6.TabIndex = 5
        Me.lblSpot6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSpot7
        '
        Me.lblSpot7.BackColor = System.Drawing.Color.White
        Me.lblSpot7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSpot7.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSpot7.Location = New System.Drawing.Point(35, 289)
        Me.lblSpot7.Name = "lblSpot7"
        Me.lblSpot7.Size = New System.Drawing.Size(116, 105)
        Me.lblSpot7.TabIndex = 6
        Me.lblSpot7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSpot8
        '
        Me.lblSpot8.BackColor = System.Drawing.Color.White
        Me.lblSpot8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSpot8.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSpot8.Location = New System.Drawing.Point(184, 289)
        Me.lblSpot8.Name = "lblSpot8"
        Me.lblSpot8.Size = New System.Drawing.Size(116, 105)
        Me.lblSpot8.TabIndex = 7
        Me.lblSpot8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSpot9
        '
        Me.lblSpot9.BackColor = System.Drawing.Color.White
        Me.lblSpot9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSpot9.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSpot9.Location = New System.Drawing.Point(332, 289)
        Me.lblSpot9.Name = "lblSpot9"
        Me.lblSpot9.Size = New System.Drawing.Size(116, 105)
        Me.lblSpot9.TabIndex = 8
        Me.lblSpot9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblMessage
        '
        Me.lblMessage.BackColor = System.Drawing.Color.Black
        Me.lblMessage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMessage.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblMessage.Location = New System.Drawing.Point(35, 423)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(413, 29)
        Me.lblMessage.TabIndex = 9
        Me.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnNewGame
        '
        Me.btnNewGame.Location = New System.Drawing.Point(74, 466)
        Me.btnNewGame.Name = "btnNewGame"
        Me.btnNewGame.Size = New System.Drawing.Size(98, 26)
        Me.btnNewGame.TabIndex = 10
        Me.btnNewGame.Text = "New Game"
        Me.btnNewGame.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(308, 466)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(98, 26)
        Me.btnExit.TabIndex = 11
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmTicTacToe
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSkyBlue
        Me.ClientSize = New System.Drawing.Size(482, 509)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnNewGame)
        Me.Controls.Add(Me.lblMessage)
        Me.Controls.Add(Me.lblSpot9)
        Me.Controls.Add(Me.lblSpot8)
        Me.Controls.Add(Me.lblSpot7)
        Me.Controls.Add(Me.lblSpot6)
        Me.Controls.Add(Me.lblSpot5)
        Me.Controls.Add(Me.lblSpot4)
        Me.Controls.Add(Me.lblSpot3)
        Me.Controls.Add(Me.lblSpot2)
        Me.Controls.Add(Me.lblSpot1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmTicTacToe"
        Me.Text = "Tic-Tac-Toe"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblSpot1 As Label
    Friend WithEvents lblSpot2 As Label
    Friend WithEvents lblSpot3 As Label
    Friend WithEvents lblSpot4 As Label
    Friend WithEvents lblSpot5 As Label
    Friend WithEvents lblSpot6 As Label
    Friend WithEvents lblSpot7 As Label
    Friend WithEvents lblSpot8 As Label
    Friend WithEvents lblSpot9 As Label
    Friend WithEvents lblMessage As Label
    Friend WithEvents btnNewGame As Button
    Friend WithEvents btnExit As Button
End Class
