﻿Public Class frmTicTacToe

    ' Member variables
    Dim gameArray(2, 2) As Integer ' A two-dimensional array with 3 rows and 3 columns
    Dim strResults(2, 2) As Char ' A two-dimensional array with 3 rows and 3 columns
    Const cLETTER_O As Char = "O" ' The letter O
    Const cLETTER_X As Char = "X" ' The letter X
    Dim rand As New Random ' Instance of the Random object
    Dim randNum1 As Integer ' The random number

    Private Sub btnNewGame_Click(sender As Object, e As EventArgs) Handles btnNewGame.Click

        ' Loop through the gameArray and assign a 0 or 1 to each index
        For intCount1 = 0 To 2
            For intCount2 = 0 To 2
                randNum1 = rand.Next(2)
                gameArray(intCount1, intCount2) = randNum1
            Next
        Next

        ' Loop through the gameArray and strResults array getting the number from the gameArray index and setting it as an O or X in the strResults array
        For intCount3 = 0 To 2
            For intCount4 = 0 To 2
                If gameArray(intCount3, intCount4) = 0 Then
                    strResults(intCount3, intCount4) = cLETTER_O
                ElseIf gameArray(intCount3, intCount4) = 1 Then
                    strResults(intCount3, intCount4) = cLETTER_X
                End If
            Next
        Next

        ' Set each label's text to the respective array index holding the letter
        lblSpot1.Text = strResults(0, 0)
        lblSpot2.Text = strResults(0, 1)
        lblSpot3.Text = strResults(0, 2)
        lblSpot4.Text = strResults(1, 0)
        lblSpot5.Text = strResults(1, 1)
        lblSpot6.Text = strResults(1, 2)
        lblSpot7.Text = strResults(2, 0)
        lblSpot8.Text = strResults(2, 1)
        lblSpot9.Text = strResults(2, 2)

        ' Check to see who won, O's or X's
        If lblSpot1.Text = cLETTER_O And lblSpot2.Text = cLETTER_O And lblSpot3.Text = cLETTER_O _
            Or lblSpot4.Text = cLETTER_O And lblSpot5.Text = cLETTER_O And lblSpot6.Text = cLETTER_O _
            Or lblSpot7.Text = cLETTER_O And lblSpot8.Text = cLETTER_O And lblSpot9.Text = cLETTER_O _
            Or lblSpot1.Text = cLETTER_O And lblSpot4.Text = cLETTER_O And lblSpot7.Text = cLETTER_O _
            Or lblSpot2.Text = cLETTER_O And lblSpot5.Text = cLETTER_O And lblSpot8.Text = cLETTER_O _
            Or lblSpot3.Text = cLETTER_O And lblSpot6.Text = cLETTER_O And lblSpot9.Text = cLETTER_O _
            Or lblSpot1.Text = cLETTER_O And lblSpot5.Text = cLETTER_O And lblSpot9.Text = cLETTER_O _
            Or lblSpot7.Text = cLETTER_O And lblSpot5.Text = cLETTER_O And lblSpot3.Text = cLETTER_O Then
            lblMessage.Text = "Player O won!"
        ElseIf lblSpot1.Text = cLETTER_X And lblSpot2.Text = cLETTER_X And lblSpot3.Text = cLETTER_X _
            Or lblSpot4.Text = cLETTER_X And lblSpot5.Text = cLETTER_X And lblSpot6.Text = cLETTER_X _
            Or lblSpot7.Text = cLETTER_X And lblSpot8.Text = cLETTER_X And lblSpot9.Text = cLETTER_X _
            Or lblSpot1.Text = cLETTER_X And lblSpot4.Text = cLETTER_X And lblSpot7.Text = cLETTER_X _
            Or lblSpot2.Text = cLETTER_X And lblSpot5.Text = cLETTER_X And lblSpot8.Text = cLETTER_X _
            Or lblSpot3.Text = cLETTER_X And lblSpot6.Text = cLETTER_X And lblSpot9.Text = cLETTER_X _
            Or lblSpot1.Text = cLETTER_X And lblSpot5.Text = cLETTER_X And lblSpot9.Text = cLETTER_X _
            Or lblSpot7.Text = cLETTER_X And lblSpot5.Text = cLETTER_X And lblSpot3.Text = cLETTER_X Then
            lblMessage.Text = "Player X won!"
        Else
            lblMessage.Text = "It's a tie!" ' If neither letter won, then it's a tie
        End If

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' End the program
        Me.Close()
    End Sub
End Class
