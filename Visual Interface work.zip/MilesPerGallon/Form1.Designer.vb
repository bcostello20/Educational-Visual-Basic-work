﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formMPGCalculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblGallonsOfGas = New System.Windows.Forms.Label()
        Me.lblNumberOfMiles = New System.Windows.Forms.Label()
        Me.txtGallonsOfGas = New System.Windows.Forms.TextBox()
        Me.txtNumberOfMiles = New System.Windows.Forms.TextBox()
        Me.lblTheMiles = New System.Windows.Forms.Label()
        Me.lblDisplayMPG = New System.Windows.Forms.Label()
        Me.btnCalculateMPG = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblGallonsOfGas
        '
        Me.lblGallonsOfGas.Location = New System.Drawing.Point(36, 31)
        Me.lblGallonsOfGas.Name = "lblGallonsOfGas"
        Me.lblGallonsOfGas.Size = New System.Drawing.Size(96, 32)
        Me.lblGallonsOfGas.TabIndex = 0
        Me.lblGallonsOfGas.Text = "Gallons of gas the car can hold:"
        '
        'lblNumberOfMiles
        '
        Me.lblNumberOfMiles.Location = New System.Drawing.Point(36, 81)
        Me.lblNumberOfMiles.Name = "lblNumberOfMiles"
        Me.lblNumberOfMiles.Size = New System.Drawing.Size(103, 42)
        Me.lblNumberOfMiles.TabIndex = 1
        Me.lblNumberOfMiles.Text = "Number of miles it can be driven on a full tank:"
        '
        'txtGallonsOfGas
        '
        Me.txtGallonsOfGas.Location = New System.Drawing.Point(174, 31)
        Me.txtGallonsOfGas.Name = "txtGallonsOfGas"
        Me.txtGallonsOfGas.Size = New System.Drawing.Size(81, 20)
        Me.txtGallonsOfGas.TabIndex = 2
        '
        'txtNumberOfMiles
        '
        Me.txtNumberOfMiles.Location = New System.Drawing.Point(174, 90)
        Me.txtNumberOfMiles.Name = "txtNumberOfMiles"
        Me.txtNumberOfMiles.Size = New System.Drawing.Size(100, 20)
        Me.txtNumberOfMiles.TabIndex = 3
        '
        'lblTheMiles
        '
        Me.lblTheMiles.AutoSize = True
        Me.lblTheMiles.Location = New System.Drawing.Point(36, 140)
        Me.lblTheMiles.Name = "lblTheMiles"
        Me.lblTheMiles.Size = New System.Drawing.Size(83, 13)
        Me.lblTheMiles.TabIndex = 4
        Me.lblTheMiles.Text = "Miles per gallon:"
        '
        'lblDisplayMPG
        '
        Me.lblDisplayMPG.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisplayMPG.Location = New System.Drawing.Point(174, 139)
        Me.lblDisplayMPG.Name = "lblDisplayMPG"
        Me.lblDisplayMPG.Size = New System.Drawing.Size(100, 22)
        Me.lblDisplayMPG.TabIndex = 5
        '
        'btnCalculateMPG
        '
        Me.btnCalculateMPG.Location = New System.Drawing.Point(39, 185)
        Me.btnCalculateMPG.Name = "btnCalculateMPG"
        Me.btnCalculateMPG.Size = New System.Drawing.Size(80, 44)
        Me.btnCalculateMPG.TabIndex = 6
        Me.btnCalculateMPG.Text = "Calculate MPG"
        Me.btnCalculateMPG.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(144, 185)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(83, 44)
        Me.btnClear.TabIndex = 7
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(251, 185)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(83, 44)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'formMPGCalculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(371, 265)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculateMPG)
        Me.Controls.Add(Me.lblDisplayMPG)
        Me.Controls.Add(Me.lblTheMiles)
        Me.Controls.Add(Me.txtNumberOfMiles)
        Me.Controls.Add(Me.txtGallonsOfGas)
        Me.Controls.Add(Me.lblNumberOfMiles)
        Me.Controls.Add(Me.lblGallonsOfGas)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "formMPGCalculator"
        Me.Text = "Miles per Gallon Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblGallonsOfGas As Label
    Friend WithEvents lblNumberOfMiles As Label
    Friend WithEvents txtGallonsOfGas As TextBox
    Friend WithEvents txtNumberOfMiles As TextBox
    Friend WithEvents lblTheMiles As Label
    Friend WithEvents lblDisplayMPG As Label
    Friend WithEvents btnCalculateMPG As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
