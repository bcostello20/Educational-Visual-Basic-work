﻿Public Class formMPGCalculator
    'Member variables declarations
    Dim intGallon As Integer 'Gallons of gas the car can hold
    Dim intMiles As Integer 'Number of miles the car can be driven on a full tank
    Dim dblMilesPerGallon As Double 'Miles per gallon

    Private Sub BtnCalculateMPG_Click(sender As Object, e As EventArgs) Handles btnCalculateMPG.Click
        Try
            'Set the variables to their values
            intGallon = CInt(txtGallonsOfGas.Text)
            intMiles = CInt(txtNumberOfMiles.Text)
            Try
                'Divide to get the MPG
                dblMilesPerGallon = CDec(intMiles / intGallon)

                'Display the MPG to the user on the screen
                lblDisplayMPG.Text = dblMilesPerGallon.ToString("n2")
            Catch ex As Exception
                ' Error message for division-by-zero.
                MessageBox.Show("Cannot divide by 0. Please change the 0.")
            End Try
        Catch ex As Exception
            'Error message for non-numeric values.
            MessageBox.Show("All input must be valid numeric values. Please try again.")
            'Set the textboxes and label to be empty
            txtGallonsOfGas.Clear()
            txtNumberOfMiles.Clear()
            lblDisplayMPG.Text = String.Empty
        End Try

    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Set the textboxes and label to be empty
        txtGallonsOfGas.Clear()
        txtNumberOfMiles.Clear()
        lblDisplayMPG.Text = String.Empty
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'End the program
        Me.Close()
    End Sub
End Class
