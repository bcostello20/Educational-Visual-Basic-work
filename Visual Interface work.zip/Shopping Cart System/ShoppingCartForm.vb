﻿Public Class ShoppingCartForm

    Dim frmPrintBooks As New PrintBooksForm ' Instance of the PrintBooksForm
    Dim frmAudioBooks As New AudioBooksForm ' Instance of the AudioBooksForm

    Private Sub PrintBooksToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuProductsPrintBooks.Click
        ' Show the PrintBooks form
        frmPrintBooks.ShowDialog()
    End Sub

    Private Sub ShoppingCartForm_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated
        ' If the String is not empty, add the String to the list box only if it is not already in the list box
        If Not g_strName = String.Empty And Not lstProducts.Items.Contains(g_strName) Then
            lstProducts.Items.Add(g_strName)
        End If
        UpdateDisplayTotal() ' Update the price labels
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        ' Remove the selected item in the list box
        Try
            With lstProducts
                .Items.RemoveAt(.SelectedIndex)
            End With
            UpdateDisplayTotal() ' Update the price labels
        Catch ex As Exception

        End Try
    End Sub

    ' Function to calculate the sub total price
    Function Calculate_SubTotal() As Decimal
        Dim decSubTotal As Decimal = 0D

        For intIndex = 0 To lstProducts.Items.Count - 1
            Dim item As String = lstProducts.Items.Item(intIndex).ToString()

            Select Case item
                Case g_strNAME_PRINT_BOOKS_ITEM_0
                    g_decPrice = g_decPRICE_PRINT_BOOKS_ITEM_0
                Case g_strNAME_PRINT_BOOKS_ITEM_1
                    g_decPrice = g_decPRICE_PRINT_BOOKS_ITEM_1
                Case g_strNAME_PRINT_BOOKS_ITEM_2
                    g_decPrice = g_decPRICE_PRINT_BOOKS_ITEM_2
                Case g_strNAME_PRINT_BOOKS_ITEM_3
                    g_decPrice = g_decPRICE_PRINT_BOOKS_ITEM_3
                Case g_strNAME_AUDIO_BOOKS_ITEM_0
                    g_decPrice = g_decPRICE_AUDIO_BOOKS_ITEM_0
                Case g_strNAME_AUDIO_BOOKS_ITEM_1
                    g_decPrice = g_decPRICE_AUDIO_BOOKS_ITEM_1
                Case g_strNAME_AUDIO_BOOKS_ITEM_2
                    g_decPrice = g_decPRICE_AUDIO_BOOKS_ITEM_2
                Case g_strNAME_AUDIO_BOOKS_ITEM_3
                    g_decPrice = g_decPRICE_AUDIO_BOOKS_ITEM_3
            End Select
            decSubTotal += g_decPrice
        Next
        Return decSubTotal
    End Function

    ' Function to calculate the tax price
    Function Calculate_Tax(ByVal decTax As Decimal) As Decimal
        decTax = Calculate_SubTotal() * g_decSALES_TAX
        Return decTax
    End Function

    ' Function to calculate the shipping cost
    Function Calculate_Shipping() As Decimal
        Dim decShipping As Decimal ' The shipping cost
        Dim decShippingCount As Decimal ' The shipping book count

        For intIndex = 0 To lstProducts.Items.Count - 1
            Dim item As String = lstProducts.Items.Item(intIndex).ToString()

            Select Case item
                Case g_strNAME_PRINT_BOOKS_ITEM_0
                    g_intBookCount = 1
                Case g_strNAME_PRINT_BOOKS_ITEM_1
                    g_intBookCount = 1
                Case g_strNAME_PRINT_BOOKS_ITEM_2
                    g_intBookCount = 1
                Case g_strNAME_PRINT_BOOKS_ITEM_3
                    g_intBookCount = 1
                Case g_strNAME_AUDIO_BOOKS_ITEM_0
                    g_intBookCount = 1
                Case g_strNAME_AUDIO_BOOKS_ITEM_1
                    g_intBookCount = 1
                Case g_strNAME_AUDIO_BOOKS_ITEM_2
                    g_intBookCount = 1
                Case g_strNAME_AUDIO_BOOKS_ITEM_3
                    g_intBookCount = 1
            End Select
            decShippingCount += g_intBookCount
            decShipping = g_decSHIPPING_COST_PER_ITEM * decShippingCount
        Next
        Return decShipping
    End Function

    ' Function to calculate the total price
    Function Calculate_Total() As Decimal
        Dim decTotal As Decimal ' The total price
        decTotal = Calculate_SubTotal() + Calculate_Tax(g_decSALES_TAX) + Calculate_Shipping()
        Return decTotal
    End Function

    ' Sub to update all the price labels 
    Sub UpdateDisplayTotal()
        lblSubTotal.Text = Calculate_SubTotal().ToString("c")
        lblTax.Text = Calculate_Tax(g_decSALES_TAX).ToString("c")
        lblShipping.Text = Calculate_Shipping().ToString("c")
        lblTotal.Text = Calculate_Total().ToString("c")
    End Sub

    Private Sub ResetToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuFileReset.Click
        ' Clear the list box and set the labels to zero dollars and cents
        lstProducts.Items.Clear()
        lblSubTotal.Text = "$0.00"
        lblTax.Text = "$0.00"
        lblShipping.Text = "$0.00"
        lblTotal.Text = "$0.00"
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        ' Close the form
        Me.Close()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuHelpAbout.Click
        ' About messsage
        MessageBox.Show("A simple shopping cart system that allows users to select from a few print and audio books and add them to a cart for pricing.")
    End Sub

    Private Sub mnuProductsAudioBooks_Click(sender As Object, e As EventArgs) Handles mnuProductsAudioBooks.Click
        ' Show the PrintBooks form
        frmAudioBooks.ShowDialog()
    End Sub
End Class
