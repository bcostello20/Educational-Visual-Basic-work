﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PrintBooksForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grbSelectPrintBook = New System.Windows.Forms.GroupBox()
        Me.lstPrintBooks = New System.Windows.Forms.ListBox()
        Me.btnAddPrintBookToCart = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.grbSelectPrintBook.SuspendLayout()
        Me.SuspendLayout()
        '
        'grbSelectPrintBook
        '
        Me.grbSelectPrintBook.Controls.Add(Me.lstPrintBooks)
        Me.grbSelectPrintBook.Location = New System.Drawing.Point(24, 29)
        Me.grbSelectPrintBook.Name = "grbSelectPrintBook"
        Me.grbSelectPrintBook.Size = New System.Drawing.Size(382, 133)
        Me.grbSelectPrintBook.TabIndex = 0
        Me.grbSelectPrintBook.TabStop = False
        Me.grbSelectPrintBook.Text = "Select a Print Book"
        '
        'lstPrintBooks
        '
        Me.lstPrintBooks.FormattingEnabled = True
        Me.lstPrintBooks.Items.AddRange(New Object() {"I Did It Your Way (Print)", "The History of Scotland (Print)", "Learn Calculus in One Day (Print)", "Feel the Stress (Print)"})
        Me.lstPrintBooks.Location = New System.Drawing.Point(24, 24)
        Me.lstPrintBooks.Name = "lstPrintBooks"
        Me.lstPrintBooks.Size = New System.Drawing.Size(330, 82)
        Me.lstPrintBooks.TabIndex = 0
        '
        'btnAddPrintBookToCart
        '
        Me.btnAddPrintBookToCart.Location = New System.Drawing.Point(92, 178)
        Me.btnAddPrintBookToCart.Name = "btnAddPrintBookToCart"
        Me.btnAddPrintBookToCart.Size = New System.Drawing.Size(119, 44)
        Me.btnAddPrintBookToCart.TabIndex = 1
        Me.btnAddPrintBookToCart.Text = "Add Book to Cart"
        Me.btnAddPrintBookToCart.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(217, 178)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(95, 44)
        Me.btnClose.TabIndex = 2
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'PrintBooksForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(433, 237)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnAddPrintBookToCart)
        Me.Controls.Add(Me.grbSelectPrintBook)
        Me.Name = "PrintBooksForm"
        Me.Text = "Print Books"
        Me.grbSelectPrintBook.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grbSelectPrintBook As GroupBox
    Friend WithEvents lstPrintBooks As ListBox
    Friend WithEvents btnAddPrintBookToCart As Button
    Friend WithEvents btnClose As Button
End Class
