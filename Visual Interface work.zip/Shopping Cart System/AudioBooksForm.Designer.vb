﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AudioBooksForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grbSelectAudioBook = New System.Windows.Forms.GroupBox()
        Me.lstAudioBooks = New System.Windows.Forms.ListBox()
        Me.btnCloseAudioForm = New System.Windows.Forms.Button()
        Me.btnAddAudioBookToCart = New System.Windows.Forms.Button()
        Me.grbSelectAudioBook.SuspendLayout()
        Me.SuspendLayout()
        '
        'grbSelectAudioBook
        '
        Me.grbSelectAudioBook.Controls.Add(Me.lstAudioBooks)
        Me.grbSelectAudioBook.Location = New System.Drawing.Point(32, 31)
        Me.grbSelectAudioBook.Name = "grbSelectAudioBook"
        Me.grbSelectAudioBook.Size = New System.Drawing.Size(381, 139)
        Me.grbSelectAudioBook.TabIndex = 0
        Me.grbSelectAudioBook.TabStop = False
        Me.grbSelectAudioBook.Text = "Select an Audio Book"
        '
        'lstAudioBooks
        '
        Me.lstAudioBooks.FormattingEnabled = True
        Me.lstAudioBooks.Items.AddRange(New Object() {"Learn Calculus in One Day (Audio)", "The History of Scotland (Audio)", "The Science of Body Language (Audio)", "Relaxation Techniques (Audio)"})
        Me.lstAudioBooks.Location = New System.Drawing.Point(23, 30)
        Me.lstAudioBooks.Name = "lstAudioBooks"
        Me.lstAudioBooks.Size = New System.Drawing.Size(333, 82)
        Me.lstAudioBooks.TabIndex = 0
        '
        'btnCloseAudioForm
        '
        Me.btnCloseAudioForm.Location = New System.Drawing.Point(231, 185)
        Me.btnCloseAudioForm.Name = "btnCloseAudioForm"
        Me.btnCloseAudioForm.Size = New System.Drawing.Size(95, 44)
        Me.btnCloseAudioForm.TabIndex = 4
        Me.btnCloseAudioForm.Text = "Close"
        Me.btnCloseAudioForm.UseVisualStyleBackColor = True
        '
        'btnAddAudioBookToCart
        '
        Me.btnAddAudioBookToCart.Location = New System.Drawing.Point(106, 185)
        Me.btnAddAudioBookToCart.Name = "btnAddAudioBookToCart"
        Me.btnAddAudioBookToCart.Size = New System.Drawing.Size(119, 44)
        Me.btnAddAudioBookToCart.TabIndex = 3
        Me.btnAddAudioBookToCart.Text = "Add Book to Cart"
        Me.btnAddAudioBookToCart.UseVisualStyleBackColor = True
        '
        'AudioBooksForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(448, 244)
        Me.Controls.Add(Me.btnCloseAudioForm)
        Me.Controls.Add(Me.btnAddAudioBookToCart)
        Me.Controls.Add(Me.grbSelectAudioBook)
        Me.Name = "AudioBooksForm"
        Me.Text = "AudioBooksForm"
        Me.grbSelectAudioBook.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grbSelectAudioBook As GroupBox
    Friend WithEvents lstAudioBooks As ListBox
    Friend WithEvents btnCloseAudioForm As Button
    Friend WithEvents btnAddAudioBookToCart As Button
End Class
