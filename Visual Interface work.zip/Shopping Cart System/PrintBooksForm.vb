﻿Public Class PrintBooksForm

    Private Sub BtnAddPrintBookToCart_Click(sender As Object, e As EventArgs) Handles btnAddPrintBookToCart.Click
        ' Add the selected book name in the list box to a String
        g_strName = lstPrintBooks.SelectedItem.ToString()
    End Sub

    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        ' Close the form
        Me.Close()
    End Sub
End Class