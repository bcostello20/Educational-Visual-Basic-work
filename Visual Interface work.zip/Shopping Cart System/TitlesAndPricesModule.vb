﻿Module TitlesAndPricesModule
    Public Const g_decSHIPPING_COST_PER_ITEM As Decimal = 2D ' The shipping cost
    Public Const g_decSALES_TAX As Decimal = 0.06D ' The sales tax

    ' Print book title constant variables
    Public Const g_strNAME_PRINT_BOOKS_ITEM_0 As String = "I Did It Your Way (Print)"
    Public Const g_strNAME_PRINT_BOOKS_ITEM_1 As String = "The History of Scotland (Print)"
    Public Const g_strNAME_PRINT_BOOKS_ITEM_2 As String = "Learn Calculus in One Day (Print)"
    Public Const g_strNAME_PRINT_BOOKS_ITEM_3 As String = "Feel the Stress (Print)"

    ' Print book prices constant variables
    Public Const g_decPRICE_PRINT_BOOKS_ITEM_0 As Decimal = 11.95D
    Public Const g_decPRICE_PRINT_BOOKS_ITEM_1 As Decimal = 14.5D
    Public Const g_decPRICE_PRINT_BOOKS_ITEM_2 As Decimal = 29.95D
    Public Const g_decPRICE_PRINT_BOOKS_ITEM_3 As Decimal = 18.5D

    ' Audio book title constant variables
    Public Const g_strNAME_AUDIO_BOOKS_ITEM_0 As String = "Learn Calculus in One Day (Audio)"
    Public Const g_strNAME_AUDIO_BOOKS_ITEM_1 As String = "The History of Scotland (Audio)"
    Public Const g_strNAME_AUDIO_BOOKS_ITEM_2 As String = "The Science of Body Language (Audio)"
    Public Const g_strNAME_AUDIO_BOOKS_ITEM_3 As String = "Relaxation Techniques (Audio)"

    ' Audio book prices constant variables
    Public Const g_decPRICE_AUDIO_BOOKS_ITEM_0 As Decimal = 29.95D
    Public Const g_decPRICE_AUDIO_BOOKS_ITEM_1 As Decimal = 14.5D
    Public Const g_decPRICE_AUDIO_BOOKS_ITEM_2 As Decimal = 12.95D
    Public Const g_decPRICE_AUDIO_BOOKS_ITEM_3 As Decimal = 11.5D

    Public g_strName As String = String.Empty
    Public g_decPrice As Decimal = 0D
    Public g_intBookCount As Integer

End Module
