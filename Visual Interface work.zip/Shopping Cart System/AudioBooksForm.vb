﻿Public Class AudioBooksForm
    Private Sub btnAddAudioBookToCart_Click(sender As Object, e As EventArgs) Handles btnAddAudioBookToCart.Click
        ' Add the selected book name in the list box to a String
        g_strName = lstAudioBooks.SelectedItem.ToString()
    End Sub

    Private Sub btnCloseAudioForm_Click(sender As Object, e As EventArgs) Handles btnCloseAudioForm.Click
        ' Close the form
        Me.Close()
    End Sub
End Class