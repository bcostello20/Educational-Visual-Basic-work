﻿Public Class Form1
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' Clear the items from the list box
        lstDemo.Items.Clear()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim intCount As Integer = 0 ' The counter
        ' While the counter is less than 10 add "Hello" to the list box each time
        Do While intCount < 10
            lstDemo.Items.Add("Hello")
            ' Increment the counter by 1
            intCount += 1
        Loop

        Dim intCount2 As Integer = 11 ' The second counter (set it to 11 to show posttest will run at least once)
        ' While the counter is less than 10 add "Goodbye" to the list box each time
        Do
            lstDemo.Items.Add("Goodbye")
            ' Increment the second counter by 1
            intCount2 += 1
        Loop While intCount2 < 10

    End Sub
End Class
