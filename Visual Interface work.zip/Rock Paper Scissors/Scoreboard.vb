﻿Public Class Scoreboard
    Private Sub btnGoBack_Click(sender As Object, e As EventArgs) Handles btnGoBack.Click
        ' Show the Game form
        frmRockPaperScissors.Show()
        ' Hide the Scoreboard form
        Me.Hide()
    End Sub
End Class