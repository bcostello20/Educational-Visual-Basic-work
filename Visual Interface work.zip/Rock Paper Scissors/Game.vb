﻿Public Class frmRockPaperScissors

    Dim intValue As Integer ' The random value
    Dim strCPUChoice As String ' The choice of the CPU
    Const strROCK As String = "Rock" ' Choice of Rock
    Const strPAPER As String = "Paper" ' Choice of Paper
    Const strSCISSORS As String = "Scissors" ' Choice of Scissors
    Dim intPlayerWinCount As Integer ' The player's win count
    Dim intCPUWinCount As Integer ' The CPU's win count
    Dim frmScoreBoard As New Scoreboard ' The Scoreboard form

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        btnPlay.Select() ' Focus on the Play button at startup

        ' Do not have any radio button selected at startup
        radRock.Checked = False
        radPaper.Checked = False
        radScissors.Checked = False


    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' End the program
        Me.Close()
    End Sub

    Private Sub btnPlay_Click(sender As Object, e As EventArgs) Handles btnPlay.Click

        intValue = CInt(Int((3 * Rnd()) + 1)) ' Generate random value between 1 and 3.

        ' Decide which choice the CPU makes based on the random value
        If intValue = 1 Then
            strCPUChoice = strROCK
        ElseIf intValue = 2 Then
            strCPUChoice = strPAPER
        ElseIf intValue = 3 Then
            strCPUChoice = strSCISSORS
        End If

        ' Checks who picks what and adds to their score
        If radRock.Checked And strCPUChoice = strROCK Then
            MessageBox.Show("It's a tie!")
        ElseIf radRock.Checked And strCPUChoice = strPAPER Then
            MessageBox.Show("CPU wins! The CPU chose: " + strCPUChoice)
            intCPUWinCount += 1
        ElseIf radRock.Checked And strCPUChoice = strSCISSORS Then
            MessageBox.Show("You win! The CPU chose: " + strCPUChoice)
            intPlayerWinCount += 1
        ElseIf radPaper.Checked And strCPUChoice = strROCK Then
            MessageBox.Show("You win! The CPU chose: " + strCPUChoice)
            intPlayerWinCount += 1
        ElseIf radPaper.Checked And strCPUChoice = strPAPER Then
            MessageBox.Show("It's a tie!")
        ElseIf radPaper.Checked And strCPUChoice = strSCISSORS Then
            MessageBox.Show("CPU wins! The CPU chose: " + strCPUChoice)
            intCPUWinCount += 1
        ElseIf radScissors.Checked And strCPUChoice = strROCK Then
            MessageBox.Show("CPU wins! The CPU chose: " + strCPUChoice)
            intCPUWinCount += 1
        ElseIf radScissors.Checked And strCPUChoice = strPAPER Then
            MessageBox.Show("You win! The CPU chose: " + strCPUChoice)
            intPlayerWinCount += 1
        ElseIf radScissors.Checked And strCPUChoice = strSCISSORS Then
            MessageBox.Show("It's a tie!")
        Else
            ' Error message if the user has not selected anything
            MessageBox.Show("You must make a selection before playing.")
        End If

        frmScoreBoard.lblPlayerScore.Text = intPlayerWinCount.ToString ' Display the player's score on the Scoreboard form
        frmScoreBoard.lblCPUScore.Text = intCPUWinCount.ToString ' Display the CPU's score on the Scoreboard form

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Uncheck the radio button selection
        radRock.Checked = False
        radPaper.Checked = False
        radScissors.Checked = False

        ' Reset the scores
        frmScoreBoard.lblPlayerScore.Text = String.Empty
        intPlayerWinCount = 0
        frmScoreBoard.lblCPUScore.Text = String.Empty
        intCPUWinCount = 0
    End Sub

    Private Sub btnViewScores_Click(sender As Object, e As EventArgs) Handles btnViewScores.Click
        ' Show the Scoreboard form
        frmScoreBoard.Show()
        ' Hide the Game form
        Me.Hide()
    End Sub
End Class
