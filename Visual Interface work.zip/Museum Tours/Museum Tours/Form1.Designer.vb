﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formMuseumTours
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbLanguage = New System.Windows.Forms.GroupBox()
        Me.rbEnglish = New System.Windows.Forms.RadioButton()
        Me.rbGerman = New System.Windows.Forms.RadioButton()
        Me.rbChinese = New System.Windows.Forms.RadioButton()
        Me.gbSections = New System.Windows.Forms.GroupBox()
        Me.cbAncientMesopotamia = New System.Windows.Forms.CheckBox()
        Me.cbAncientEurope = New System.Windows.Forms.CheckBox()
        Me.cbMedievalEurope = New System.Windows.Forms.CheckBox()
        Me.cbEastAsia = New System.Windows.Forms.CheckBox()
        Me.btnContinue = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblCostOfTourDesc = New System.Windows.Forms.Label()
        Me.lblCostOfTour = New System.Windows.Forms.Label()
        Me.lblLanguageDesc = New System.Windows.Forms.Label()
        Me.lblLanguageSelected = New System.Windows.Forms.Label()
        Me.lstSections = New System.Windows.Forms.ListBox()
        Me.lblSectionsToVisitDesc = New System.Windows.Forms.Label()
        Me.gbLanguage.SuspendLayout()
        Me.gbSections.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbLanguage
        '
        Me.gbLanguage.Controls.Add(Me.rbChinese)
        Me.gbLanguage.Controls.Add(Me.rbGerman)
        Me.gbLanguage.Controls.Add(Me.rbEnglish)
        Me.gbLanguage.Location = New System.Drawing.Point(21, 25)
        Me.gbLanguage.Name = "gbLanguage"
        Me.gbLanguage.Size = New System.Drawing.Size(133, 134)
        Me.gbLanguage.TabIndex = 0
        Me.gbLanguage.TabStop = False
        Me.gbLanguage.Text = "Select a language"
        '
        'rbEnglish
        '
        Me.rbEnglish.AutoSize = True
        Me.rbEnglish.Location = New System.Drawing.Point(28, 30)
        Me.rbEnglish.Name = "rbEnglish"
        Me.rbEnglish.Size = New System.Drawing.Size(59, 17)
        Me.rbEnglish.TabIndex = 0
        Me.rbEnglish.TabStop = True
        Me.rbEnglish.Text = "English"
        Me.rbEnglish.UseVisualStyleBackColor = True
        '
        'rbGerman
        '
        Me.rbGerman.AutoSize = True
        Me.rbGerman.Location = New System.Drawing.Point(28, 64)
        Me.rbGerman.Name = "rbGerman"
        Me.rbGerman.Size = New System.Drawing.Size(62, 17)
        Me.rbGerman.TabIndex = 1
        Me.rbGerman.TabStop = True
        Me.rbGerman.Text = "German"
        Me.rbGerman.UseVisualStyleBackColor = True
        '
        'rbChinese
        '
        Me.rbChinese.AutoSize = True
        Me.rbChinese.Location = New System.Drawing.Point(28, 100)
        Me.rbChinese.Name = "rbChinese"
        Me.rbChinese.Size = New System.Drawing.Size(63, 17)
        Me.rbChinese.TabIndex = 2
        Me.rbChinese.TabStop = True
        Me.rbChinese.Text = "Chinese"
        Me.rbChinese.UseVisualStyleBackColor = True
        '
        'gbSections
        '
        Me.gbSections.Controls.Add(Me.cbEastAsia)
        Me.gbSections.Controls.Add(Me.cbMedievalEurope)
        Me.gbSections.Controls.Add(Me.cbAncientEurope)
        Me.gbSections.Controls.Add(Me.cbAncientMesopotamia)
        Me.gbSections.Location = New System.Drawing.Point(21, 181)
        Me.gbSections.Name = "gbSections"
        Me.gbSections.Size = New System.Drawing.Size(200, 171)
        Me.gbSections.TabIndex = 1
        Me.gbSections.TabStop = False
        Me.gbSections.Text = "Select a section"
        '
        'cbAncientMesopotamia
        '
        Me.cbAncientMesopotamia.AutoSize = True
        Me.cbAncientMesopotamia.Location = New System.Drawing.Point(29, 30)
        Me.cbAncientMesopotamia.Name = "cbAncientMesopotamia"
        Me.cbAncientMesopotamia.Size = New System.Drawing.Size(128, 17)
        Me.cbAncientMesopotamia.TabIndex = 0
        Me.cbAncientMesopotamia.Text = "Ancient Mesopotamia"
        Me.cbAncientMesopotamia.UseVisualStyleBackColor = True
        '
        'cbAncientEurope
        '
        Me.cbAncientEurope.AutoSize = True
        Me.cbAncientEurope.Location = New System.Drawing.Point(29, 64)
        Me.cbAncientEurope.Name = "cbAncientEurope"
        Me.cbAncientEurope.Size = New System.Drawing.Size(99, 17)
        Me.cbAncientEurope.TabIndex = 1
        Me.cbAncientEurope.Text = "Ancient Europe"
        Me.cbAncientEurope.UseVisualStyleBackColor = True
        '
        'cbMedievalEurope
        '
        Me.cbMedievalEurope.AutoSize = True
        Me.cbMedievalEurope.Location = New System.Drawing.Point(29, 100)
        Me.cbMedievalEurope.Name = "cbMedievalEurope"
        Me.cbMedievalEurope.Size = New System.Drawing.Size(106, 17)
        Me.cbMedievalEurope.TabIndex = 2
        Me.cbMedievalEurope.Text = "Medieval Europe"
        Me.cbMedievalEurope.UseVisualStyleBackColor = True
        '
        'cbEastAsia
        '
        Me.cbEastAsia.AutoSize = True
        Me.cbEastAsia.Location = New System.Drawing.Point(29, 134)
        Me.cbEastAsia.Name = "cbEastAsia"
        Me.cbEastAsia.Size = New System.Drawing.Size(70, 17)
        Me.cbEastAsia.TabIndex = 3
        Me.cbEastAsia.Text = "East Asia"
        Me.cbEastAsia.UseVisualStyleBackColor = True
        '
        'btnContinue
        '
        Me.btnContinue.Location = New System.Drawing.Point(272, 311)
        Me.btnContinue.Name = "btnContinue"
        Me.btnContinue.Size = New System.Drawing.Size(104, 41)
        Me.btnContinue.TabIndex = 2
        Me.btnContinue.Text = "Continue"
        Me.btnContinue.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(382, 311)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(104, 41)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblCostOfTourDesc
        '
        Me.lblCostOfTourDesc.AutoSize = True
        Me.lblCostOfTourDesc.Location = New System.Drawing.Point(269, 25)
        Me.lblCostOfTourDesc.Name = "lblCostOfTourDesc"
        Me.lblCostOfTourDesc.Size = New System.Drawing.Size(64, 13)
        Me.lblCostOfTourDesc.TabIndex = 4
        Me.lblCostOfTourDesc.Text = "Cost of tour:"
        '
        'lblCostOfTour
        '
        Me.lblCostOfTour.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCostOfTour.Location = New System.Drawing.Point(339, 24)
        Me.lblCostOfTour.Name = "lblCostOfTour"
        Me.lblCostOfTour.Size = New System.Drawing.Size(113, 23)
        Me.lblCostOfTour.TabIndex = 5
        '
        'lblLanguageDesc
        '
        Me.lblLanguageDesc.AutoSize = True
        Me.lblLanguageDesc.Location = New System.Drawing.Point(232, 79)
        Me.lblLanguageDesc.Name = "lblLanguageDesc"
        Me.lblLanguageDesc.Size = New System.Drawing.Size(101, 13)
        Me.lblLanguageDesc.TabIndex = 6
        Me.lblLanguageDesc.Text = "Language selected:"
        '
        'lblLanguageSelected
        '
        Me.lblLanguageSelected.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblLanguageSelected.Location = New System.Drawing.Point(339, 78)
        Me.lblLanguageSelected.Name = "lblLanguageSelected"
        Me.lblLanguageSelected.Size = New System.Drawing.Size(113, 23)
        Me.lblLanguageSelected.TabIndex = 7
        '
        'lstSections
        '
        Me.lstSections.FormattingEnabled = True
        Me.lstSections.Location = New System.Drawing.Point(339, 133)
        Me.lstSections.Name = "lstSections"
        Me.lstSections.Size = New System.Drawing.Size(172, 134)
        Me.lstSections.TabIndex = 8
        '
        'lblSectionsToVisitDesc
        '
        Me.lblSectionsToVisitDesc.AutoSize = True
        Me.lblSectionsToVisitDesc.Location = New System.Drawing.Point(249, 133)
        Me.lblSectionsToVisitDesc.Name = "lblSectionsToVisitDesc"
        Me.lblSectionsToVisitDesc.Size = New System.Drawing.Size(84, 13)
        Me.lblSectionsToVisitDesc.TabIndex = 9
        Me.lblSectionsToVisitDesc.Text = "Sections to visit:"
        '
        'formMuseumTours
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(536, 374)
        Me.Controls.Add(Me.lblSectionsToVisitDesc)
        Me.Controls.Add(Me.lstSections)
        Me.Controls.Add(Me.lblLanguageSelected)
        Me.Controls.Add(Me.lblLanguageDesc)
        Me.Controls.Add(Me.lblCostOfTour)
        Me.Controls.Add(Me.lblCostOfTourDesc)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnContinue)
        Me.Controls.Add(Me.gbSections)
        Me.Controls.Add(Me.gbLanguage)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "formMuseumTours"
        Me.Text = "Museum Tours"
        Me.gbLanguage.ResumeLayout(False)
        Me.gbLanguage.PerformLayout()
        Me.gbSections.ResumeLayout(False)
        Me.gbSections.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents gbLanguage As GroupBox
    Friend WithEvents rbChinese As RadioButton
    Friend WithEvents rbGerman As RadioButton
    Friend WithEvents rbEnglish As RadioButton
    Friend WithEvents gbSections As GroupBox
    Friend WithEvents cbEastAsia As CheckBox
    Friend WithEvents cbMedievalEurope As CheckBox
    Friend WithEvents cbAncientEurope As CheckBox
    Friend WithEvents cbAncientMesopotamia As CheckBox
    Friend WithEvents btnContinue As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblCostOfTourDesc As Label
    Friend WithEvents lblCostOfTour As Label
    Friend WithEvents lblLanguageDesc As Label
    Friend WithEvents lblLanguageSelected As Label
    Friend WithEvents lstSections As ListBox
    Friend WithEvents lblSectionsToVisitDesc As Label
End Class
