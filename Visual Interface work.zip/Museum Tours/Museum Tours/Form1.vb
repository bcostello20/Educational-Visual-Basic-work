﻿Public Class formMuseumTours
    Private Sub btnContinue_Click(sender As Object, e As EventArgs) Handles btnContinue.Click
        ' Member variables
        Const ANCIENT_MESOPOTAMIA_COST As Integer = 3000I
        Const ANCIENT_EUROPE_COST As Integer = 1500I
        Const MEDIEVAL_EUROPE_COST As Integer = 1000I
        Const EAST_ASIA_COST As Integer = 2500I
        Dim total As Integer ' The total tour cost

        ' Determine the cost of the tour
        If cbAncientMesopotamia.Checked Then
            total += ANCIENT_MESOPOTAMIA_COST
        End If

        If cbAncientEurope.Checked Then
            total += ANCIENT_EUROPE_COST
        End If

        If cbMedievalEurope.Checked Then
            total += MEDIEVAL_EUROPE_COST
        End If

        If cbEastAsia.Checked Then
            total += EAST_ASIA_COST
        End If

        ' Display the tour cost
        lblCostOfTour.Text = (total.ToString("c"))

        ' Figure out and display the language selected
        If rbEnglish.Checked Then
            lblLanguageSelected.Text = rbEnglish.Text
        ElseIf rbGerman.Checked Then
            lblLanguageSelected.Text = rbGerman.Text
        ElseIf rbChinese.Checked Then
            lblLanguageSelected.Text = rbChinese.Text
        End If

        ' Display the list of museum sections the user plans to visit
        ' If the item is already in the list box it will not be added again
        If cbAncientMesopotamia.Checked Then
            If Not lstSections.Items.Contains(cbAncientMesopotamia.Text) Then
                lstSections.Items.Add(cbAncientMesopotamia.Text)
            End If
        End If

        If cbAncientEurope.Checked Then
            If Not lstSections.Items.Contains(cbAncientEurope.Text) Then
                lstSections.Items.Add(cbAncientEurope.Text)
            End If
        End If

        If cbMedievalEurope.Checked Then
            If Not lstSections.Items.Contains(cbMedievalEurope.Text) Then
                lstSections.Items.Add(cbMedievalEurope.Text)
            End If
        End If

        If cbEastAsia.Checked Then
            If Not lstSections.Items.Contains(cbEastAsia.Text) Then
                lstSections.Items.Add(cbEastAsia.Text)
            End If
        End If

        ' If the checkbox for the item was unchecked then remove the item from the list box
        If Not cbAncientMesopotamia.Checked Then
            lstSections.Items.Remove(cbAncientMesopotamia.Text)
        End If

        If Not cbAncientEurope.Checked Then
            lstSections.Items.Remove(cbAncientEurope.Text)
        End If

        If Not cbMedievalEurope.Checked Then
            lstSections.Items.Remove(cbMedievalEurope.Text)
        End If

        If Not cbEastAsia.Checked Then
            lstSections.Items.Remove(cbEastAsia.Text)
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' End the program
        Me.Close()
    End Sub
End Class
