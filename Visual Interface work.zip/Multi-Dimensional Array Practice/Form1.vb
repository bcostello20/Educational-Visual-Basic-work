﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strArray(,) As String = {{" ", " ", "*", " ", " "},
                                     {" ", "*", "*", "*", " "},
                                     {"*", "*", "*", "*", "*"},
                                     {" ", "*", "*", "*", " "},
                                     {" ", " ", "*", " ", " "}}

        Dim intUpperBound As Integer = strArray.GetUpperBound(0)
        Dim intUpperBound2 As Integer = strArray.GetUpperBound(1)

        Dim intIndex0, intIndex1 As Integer
        txtOutput.AppendText(vbTab)
        For intIndex0 = 0 To intUpperBound
            For intIndex1 = 0 To intUpperBound2
                txtOutput.AppendText(strArray(intIndex0, intIndex1).ToString())
            Next
            txtOutput.AppendText(vbCrLf & vbTab)
        Next
    End Sub
End Class
