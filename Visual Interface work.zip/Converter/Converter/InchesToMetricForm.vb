﻿Public Class InchesToMetricForm
    Private Sub BtnConvertToMillimeters_Click(sender As Object, e As EventArgs) Handles btnConvertToMillimeters.Click
        Dim dblInches As Double ' To store the inches
        Dim dblMillimeters As Double ' To store the millimeters

        Try
            ' Get the inches
            dblInches = CDbl(txtInches.Text)

            ' Convert inches to millimeters
            dblMillimeters = InchesToMM(dblInches)

            ' Display the result
            MessageBox.Show(dblInches.ToString() & " inches equals " & dblMillimeters.ToString() & " millimeters.")
        Catch
            ' Error message for invalid input
            MessageBox.Show("ERROR: Input must be numeric")
        End Try
    End Sub

    Private Sub BtnConvertToCentimeters_Click(sender As Object, e As EventArgs) Handles btnConvertToCentimeters.Click
        Dim dblInches As Double ' To store the inches
        Dim dblCentimeters As Double ' To store the centimeters

        Try
            ' Get the inches
            dblInches = CDbl(txtInches.Text)

            ' Convert inches to centimeters
            dblCentimeters = InchesToCM(dblInches)

            ' Display the result
            MessageBox.Show(dblInches.ToString() & " inches equals " & dblCentimeters.ToString() & " centimeters.")
        Catch
            ' Error message for invalid input
            MessageBox.Show("ERROR: Input must be numeric")
        End Try
    End Sub

    Private Sub BtnConvertToMeters_Click(sender As Object, e As EventArgs) Handles btnConvertToMeters.Click
        Dim dblInches As Double ' To store the inches
        Dim dblMeters As Double ' To store the meters

        Try
            ' Get the inches
            dblInches = CDbl(txtInches.Text)

            ' Convert inches to meters
            dblMeters = InchesToMeters(dblInches)

            ' Display the result
            MessageBox.Show(dblInches.ToString() & " inches equals " & dblMeters.ToString() & " meters.")
        Catch
            ' Error message for invalid input
            MessageBox.Show("ERROR: Input must be numeric")
        End Try
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        ' Close the form
        Me.Close()
    End Sub
End Class