﻿Public Class MetersToEnglishForm
    Private Sub btnConvertToInches_Click(sender As Object, e As EventArgs) Handles btnConvertToInches.Click
        Dim dblMeters As Double ' To store the meters
        Dim dblInches As Double ' To store the inches

        Try
            ' Get the meters
            dblMeters = CDbl(txtMeters.Text)

            ' Convert meters to inches
            dblInches = MetersToInches(dblMeters)

            ' Display the result
            MessageBox.Show(dblMeters.ToString() & " meters equals " & dblInches.ToString() & " inches.")
        Catch
            ' Error message for invalid input
            MessageBox.Show("ERROR: Input must be numeric")
        End Try
    End Sub

    Private Sub btnConvertToFeet_Click(sender As Object, e As EventArgs) Handles btnConvertToFeet.Click
        Dim dblMeters As Double ' To store the meters
        Dim dblFeet As Double ' To store the feet

        Try
            ' Get the meters
            dblMeters = CDbl(txtMeters.Text)

            ' Convert meters to feet
            dblFeet = MetersToFeet(dblMeters)

            ' Display the result
            MessageBox.Show(dblMeters.ToString() & " meters equals " & dblFeet.ToString() & " feet.")
        Catch
            ' Error message for invalid input
            MessageBox.Show("ERROR: Input must be numeric")
        End Try
    End Sub

    Private Sub btnConvertToYards_Click(sender As Object, e As EventArgs) Handles btnConvertToYards.Click
        Dim dblMeters As Double ' To store the meters
        Dim dblYards As Double ' To store the yards

        Try
            ' Get the meters
            dblMeters = CDbl(txtMeters.Text)

            ' Convert meters to yards
            dblYards = MetersToYards(dblMeters)

            ' Display the result
            MessageBox.Show(dblMeters.ToString() & " meters equals " & dblYards.ToString() & " yards.")
        Catch
            ' Error message for invalid input
            MessageBox.Show("ERROR: Input must be numeric")
        End Try
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        ' Close the form
        Me.Close()
    End Sub
End Class