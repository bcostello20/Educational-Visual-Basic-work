﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class InchesToMetricForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtInches = New System.Windows.Forms.TextBox()
        Me.btnConvertToMillimeters = New System.Windows.Forms.Button()
        Me.btnConvertToCentimeters = New System.Windows.Forms.Button()
        Me.btnConvertToMeters = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(137, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter the number of inches:"
        '
        'txtInches
        '
        Me.txtInches.Location = New System.Drawing.Point(156, 23)
        Me.txtInches.Name = "txtInches"
        Me.txtInches.Size = New System.Drawing.Size(100, 20)
        Me.txtInches.TabIndex = 1
        '
        'btnConvertToMillimeters
        '
        Me.btnConvertToMillimeters.Location = New System.Drawing.Point(16, 65)
        Me.btnConvertToMillimeters.Name = "btnConvertToMillimeters"
        Me.btnConvertToMillimeters.Size = New System.Drawing.Size(75, 39)
        Me.btnConvertToMillimeters.TabIndex = 2
        Me.btnConvertToMillimeters.Text = "Convert to Millimeters"
        Me.btnConvertToMillimeters.UseVisualStyleBackColor = True
        '
        'btnConvertToCentimeters
        '
        Me.btnConvertToCentimeters.Location = New System.Drawing.Point(97, 65)
        Me.btnConvertToCentimeters.Name = "btnConvertToCentimeters"
        Me.btnConvertToCentimeters.Size = New System.Drawing.Size(75, 39)
        Me.btnConvertToCentimeters.TabIndex = 3
        Me.btnConvertToCentimeters.Text = "Convert to Centimeters"
        Me.btnConvertToCentimeters.UseVisualStyleBackColor = True
        '
        'btnConvertToMeters
        '
        Me.btnConvertToMeters.Location = New System.Drawing.Point(178, 65)
        Me.btnConvertToMeters.Name = "btnConvertToMeters"
        Me.btnConvertToMeters.Size = New System.Drawing.Size(75, 39)
        Me.btnConvertToMeters.TabIndex = 4
        Me.btnConvertToMeters.Text = "Convert to Meters"
        Me.btnConvertToMeters.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(97, 110)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 39)
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'InchesToMetricForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(270, 162)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnConvertToMeters)
        Me.Controls.Add(Me.btnConvertToCentimeters)
        Me.Controls.Add(Me.btnConvertToMillimeters)
        Me.Controls.Add(Me.txtInches)
        Me.Controls.Add(Me.Label1)
        Me.Name = "InchesToMetricForm"
        Me.Text = "Inches to Metric"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtInches As TextBox
    Friend WithEvents btnConvertToMillimeters As Button
    Friend WithEvents btnConvertToCentimeters As Button
    Friend WithEvents btnConvertToMeters As Button
    Friend WithEvents btnClose As Button
End Class
