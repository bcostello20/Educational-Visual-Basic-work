﻿Public Class MainForm
    Private Sub btnMetersToEnglish_Click(sender As Object, e As EventArgs) Handles btnMetersToEnglish.Click
        Dim frmMeters As New MetersToEnglishForm ' Instance of the MetersToEnglishForm
        frmMeters.ShowDialog() ' Show the form
    End Sub

    Private Sub btnMetersToInches_Click(sender As Object, e As EventArgs) Handles btnMetersToInches.Click
        Dim frmInches As New InchesToMetricForm ' Instance of the InchesToMetricForm
        frmInches.ShowDialog() ' Show the form
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' Close the form
        Me.Close()
    End Sub
End Class
