﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblInstruction = New System.Windows.Forms.Label()
        Me.btnMetersToEnglish = New System.Windows.Forms.Button()
        Me.btnMetersToInches = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblInstruction
        '
        Me.lblInstruction.Location = New System.Drawing.Point(12, 23)
        Me.lblInstruction.Name = "lblInstruction"
        Me.lblInstruction.Size = New System.Drawing.Size(250, 32)
        Me.lblInstruction.TabIndex = 0
        Me.lblInstruction.Text = "This application converts meters to various English         units, and inches to " &
    "various metric units."
        '
        'btnMetersToEnglish
        '
        Me.btnMetersToEnglish.Location = New System.Drawing.Point(15, 71)
        Me.btnMetersToEnglish.Name = "btnMetersToEnglish"
        Me.btnMetersToEnglish.Size = New System.Drawing.Size(75, 37)
        Me.btnMetersToEnglish.TabIndex = 1
        Me.btnMetersToEnglish.Text = "Convert Meters"
        Me.btnMetersToEnglish.UseVisualStyleBackColor = True
        '
        'btnMetersToInches
        '
        Me.btnMetersToInches.Location = New System.Drawing.Point(96, 71)
        Me.btnMetersToInches.Name = "btnMetersToInches"
        Me.btnMetersToInches.Size = New System.Drawing.Size(75, 37)
        Me.btnMetersToInches.TabIndex = 2
        Me.btnMetersToInches.Text = "Convert Inches"
        Me.btnMetersToInches.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(177, 71)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 37)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(271, 121)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnMetersToInches)
        Me.Controls.Add(Me.btnMetersToEnglish)
        Me.Controls.Add(Me.lblInstruction)
        Me.Name = "MainForm"
        Me.Text = "Converter"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblInstruction As Label
    Friend WithEvents btnMetersToEnglish As Button
    Friend WithEvents btnMetersToInches As Button
    Friend WithEvents btnExit As Button
End Class
