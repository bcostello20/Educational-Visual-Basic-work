﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MetersToEnglishForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtMeters = New System.Windows.Forms.TextBox()
        Me.btnConvertToInches = New System.Windows.Forms.Button()
        Me.btnConvertToFeet = New System.Windows.Forms.Button()
        Me.btnConvertToYards = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(137, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter the number of meters:"
        '
        'txtMeters
        '
        Me.txtMeters.Location = New System.Drawing.Point(156, 23)
        Me.txtMeters.Name = "txtMeters"
        Me.txtMeters.Size = New System.Drawing.Size(100, 20)
        Me.txtMeters.TabIndex = 1
        '
        'btnConvertToInches
        '
        Me.btnConvertToInches.Location = New System.Drawing.Point(16, 63)
        Me.btnConvertToInches.Name = "btnConvertToInches"
        Me.btnConvertToInches.Size = New System.Drawing.Size(75, 36)
        Me.btnConvertToInches.TabIndex = 2
        Me.btnConvertToInches.Text = "Convert to Inches"
        Me.btnConvertToInches.UseVisualStyleBackColor = True
        '
        'btnConvertToFeet
        '
        Me.btnConvertToFeet.Location = New System.Drawing.Point(97, 63)
        Me.btnConvertToFeet.Name = "btnConvertToFeet"
        Me.btnConvertToFeet.Size = New System.Drawing.Size(75, 36)
        Me.btnConvertToFeet.TabIndex = 3
        Me.btnConvertToFeet.Text = "Convert to Feet"
        Me.btnConvertToFeet.UseVisualStyleBackColor = True
        '
        'btnConvertToYards
        '
        Me.btnConvertToYards.Location = New System.Drawing.Point(178, 63)
        Me.btnConvertToYards.Name = "btnConvertToYards"
        Me.btnConvertToYards.Size = New System.Drawing.Size(75, 36)
        Me.btnConvertToYards.TabIndex = 4
        Me.btnConvertToYards.Text = "Convert to Yards"
        Me.btnConvertToYards.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(97, 105)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 36)
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'MetersToEnglishForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(272, 154)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnConvertToYards)
        Me.Controls.Add(Me.btnConvertToFeet)
        Me.Controls.Add(Me.btnConvertToInches)
        Me.Controls.Add(Me.txtMeters)
        Me.Controls.Add(Me.Label1)
        Me.Name = "MetersToEnglishForm"
        Me.Text = "Meters to English"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtMeters As TextBox
    Friend WithEvents btnConvertToInches As Button
    Friend WithEvents btnConvertToFeet As Button
    Friend WithEvents btnConvertToYards As Button
    Friend WithEvents btnClose As Button
End Class
