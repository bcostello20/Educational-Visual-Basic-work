﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formCrazyAl
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblSalesDesc = New System.Windows.Forms.Label()
        Me.txtSales = New System.Windows.Forms.TextBox()
        Me.lblAdvancePayDesc = New System.Windows.Forms.Label()
        Me.txtAdvancePay = New System.Windows.Forms.TextBox()
        Me.lblCommissionRateDesc = New System.Windows.Forms.Label()
        Me.lblCommissionRate = New System.Windows.Forms.Label()
        Me.lblCommissionDesc = New System.Windows.Forms.Label()
        Me.lblCommissionAmount = New System.Windows.Forms.Label()
        Me.lblNetPayDesc = New System.Windows.Forms.Label()
        Me.lblNetPay = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.lblStatus = New System.Windows.Forms.ToolStripStatusLabel()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblSalesDesc
        '
        Me.lblSalesDesc.AutoSize = True
        Me.lblSalesDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSalesDesc.Location = New System.Drawing.Point(74, 46)
        Me.lblSalesDesc.Name = "lblSalesDesc"
        Me.lblSalesDesc.Size = New System.Drawing.Size(135, 17)
        Me.lblSalesDesc.TabIndex = 0
        Me.lblSalesDesc.Text = "Sales for the month:"
        '
        'txtSales
        '
        Me.txtSales.Location = New System.Drawing.Point(215, 46)
        Me.txtSales.Name = "txtSales"
        Me.txtSales.Size = New System.Drawing.Size(100, 20)
        Me.txtSales.TabIndex = 1
        '
        'lblAdvancePayDesc
        '
        Me.lblAdvancePayDesc.AutoSize = True
        Me.lblAdvancePayDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAdvancePayDesc.Location = New System.Drawing.Point(57, 86)
        Me.lblAdvancePayDesc.Name = "lblAdvancePayDesc"
        Me.lblAdvancePayDesc.Size = New System.Drawing.Size(152, 17)
        Me.lblAdvancePayDesc.TabIndex = 2
        Me.lblAdvancePayDesc.Text = "Advance pay awarded:"
        '
        'txtAdvancePay
        '
        Me.txtAdvancePay.Location = New System.Drawing.Point(215, 86)
        Me.txtAdvancePay.Name = "txtAdvancePay"
        Me.txtAdvancePay.Size = New System.Drawing.Size(100, 20)
        Me.txtAdvancePay.TabIndex = 3
        '
        'lblCommissionRateDesc
        '
        Me.lblCommissionRateDesc.AutoSize = True
        Me.lblCommissionRateDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCommissionRateDesc.Location = New System.Drawing.Point(88, 142)
        Me.lblCommissionRateDesc.Name = "lblCommissionRateDesc"
        Me.lblCommissionRateDesc.Size = New System.Drawing.Size(121, 17)
        Me.lblCommissionRateDesc.TabIndex = 4
        Me.lblCommissionRateDesc.Text = "Commission Rate:"
        '
        'lblCommissionRate
        '
        Me.lblCommissionRate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCommissionRate.Location = New System.Drawing.Point(215, 142)
        Me.lblCommissionRate.Name = "lblCommissionRate"
        Me.lblCommissionRate.Size = New System.Drawing.Size(100, 23)
        Me.lblCommissionRate.TabIndex = 5
        '
        'lblCommissionDesc
        '
        Me.lblCommissionDesc.AutoSize = True
        Me.lblCommissionDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCommissionDesc.Location = New System.Drawing.Point(122, 176)
        Me.lblCommissionDesc.Name = "lblCommissionDesc"
        Me.lblCommissionDesc.Size = New System.Drawing.Size(87, 17)
        Me.lblCommissionDesc.TabIndex = 6
        Me.lblCommissionDesc.Text = "Commission:"
        '
        'lblCommissionAmount
        '
        Me.lblCommissionAmount.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCommissionAmount.Location = New System.Drawing.Point(215, 176)
        Me.lblCommissionAmount.Name = "lblCommissionAmount"
        Me.lblCommissionAmount.Size = New System.Drawing.Size(100, 23)
        Me.lblCommissionAmount.TabIndex = 7
        '
        'lblNetPayDesc
        '
        Me.lblNetPayDesc.AutoSize = True
        Me.lblNetPayDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNetPayDesc.Location = New System.Drawing.Point(147, 210)
        Me.lblNetPayDesc.Name = "lblNetPayDesc"
        Me.lblNetPayDesc.Size = New System.Drawing.Size(62, 17)
        Me.lblNetPayDesc.TabIndex = 8
        Me.lblNetPayDesc.Text = "Net Pay:"
        '
        'lblNetPay
        '
        Me.lblNetPay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNetPay.Location = New System.Drawing.Point(215, 210)
        Me.lblNetPay.Name = "lblNetPay"
        Me.lblNetPay.Size = New System.Drawing.Size(100, 23)
        Me.lblNetPay.TabIndex = 9
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(28, 264)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(92, 28)
        Me.btnCalculate.TabIndex = 10
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(168, 264)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(92, 28)
        Me.btnClear.TabIndex = 11
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(266, 264)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(92, 28)
        Me.btnExit.TabIndex = 12
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblStatus})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 318)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(400, 22)
        Me.StatusStrip1.TabIndex = 13
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'lblStatus
        '
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(0, 17)
        '
        'formCrazyAl
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(400, 340)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblNetPay)
        Me.Controls.Add(Me.lblNetPayDesc)
        Me.Controls.Add(Me.lblCommissionAmount)
        Me.Controls.Add(Me.lblCommissionDesc)
        Me.Controls.Add(Me.lblCommissionRate)
        Me.Controls.Add(Me.lblCommissionRateDesc)
        Me.Controls.Add(Me.txtAdvancePay)
        Me.Controls.Add(Me.lblAdvancePayDesc)
        Me.Controls.Add(Me.txtSales)
        Me.Controls.Add(Me.lblSalesDesc)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "formCrazyAl"
        Me.Text = "Crazy Al's Commission Calculator"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblSalesDesc As Label
    Friend WithEvents txtSales As TextBox
    Friend WithEvents lblAdvancePayDesc As Label
    Friend WithEvents txtAdvancePay As TextBox
    Friend WithEvents lblCommissionRateDesc As Label
    Friend WithEvents lblCommissionRate As Label
    Friend WithEvents lblCommissionDesc As Label
    Friend WithEvents lblCommissionAmount As Label
    Friend WithEvents lblNetPayDesc As Label
    Friend WithEvents lblNetPay As Label
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents lblStatus As ToolStripStatusLabel
End Class
