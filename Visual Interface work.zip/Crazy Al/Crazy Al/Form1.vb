﻿Public Class formCrazyAl
    Private Sub BtnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        ' Member variables
        Dim decSalesAmount As Decimal ' The monthly sales amount
        Dim decAdvancePayAmount As Decimal ' The advance pay amount
        Dim decCommissionRate As Decimal ' The commission rate
        Dim decCommissionAmount As Decimal ' The commission amount
        Dim decNetPay As Decimal ' The net pay

        Try
            ' Clear any possible previous error messages
            lblStatus.Text = String.Empty

            ' Get the sales amount
            decSalesAmount = CDec(txtSales.Text)

            ' Get the advance pay amount
            decAdvancePayAmount = CDec(txtAdvancePay.Text)

            ' Figure out the commission rate
            Select Case decSalesAmount
                Case Is < 10000
                    decCommissionRate = 0.05D

                Case 10000 To 14999
                    decCommissionRate = 0.1D

                Case 15000 To 17999
                    decCommissionRate = 0.12D

                Case 18000 To 21999
                    decCommissionRate = 0.14D

                Case Is >= 22000
                    decCommissionRate = 0.15D
            End Select

            ' Calculate both the commission and net pay amounts
            decCommissionAmount = decSalesAmount * decCommissionRate
            decNetPay = decCommissionAmount - decAdvancePayAmount

            ' Display the rate, commission, and net pay to the screen
            lblCommissionRate.Text = decCommissionRate.ToString("p")
            lblCommissionAmount.Text = decCommissionAmount.ToString("c")

            ' Check if net pay is a positive or negative value to display it properly
            If decNetPay >= 0 Then
                lblNetPay.Text = decNetPay.ToString("c")
            Else
                lblNetPay.Text = "-" & (decNetPay * (-1)).ToString("c")
            End If

        Catch
            ' Display an error message telling the user they entered invalid input
            lblStatus.Text = "Please enter numeric values."
        End Try
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clear the text boxes
        txtSales.Clear()
        txtAdvancePay.Clear()

        ' Empty the labels
        lblCommissionRate.Text = String.Empty
        lblCommissionAmount.Text = String.Empty
        lblNetPay.Text = String.Empty
        lblStatus.Text = String.Empty
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
